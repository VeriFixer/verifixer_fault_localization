// dafny-synthesis_task_id_80.dfy

method TetrahedralNumber(n: int) returns (t: int)
  requires n >= 0
  ensures t == n * (n + 1) * (n + 2) / 6
  decreases n
{
  t := n * (n + 1) * (n + 2) / 6;
}
