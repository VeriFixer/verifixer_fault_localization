// Dafny_Learning_Experience_tmp_tmpuxvcet_u_week8_12_a3_search_findPositionOfIndex.dfy

method FindPositionOfElement(a: array<int>, Element: nat, n1: nat, s1: seq<int>)
    returns (Position: int, Count: nat)
  requires n1 == |s1| && 0 <= n1 <= a.Length
  requires forall i: int {:trigger s1[i]} {:trigger a[i]} :: 0 <= i < |s1| ==> a[i] == s1[i]
  ensures Position == -1 || Position >= 1
  ensures |s1| != 0 && Position >= 1 ==> exists i: int {:trigger s1[i]} :: 0 <= i < |s1| && s1[i] == Element
  decreases a, Element, n1, s1
{
  Count := 0;
  Position := 0;
  while Count != n1
    invariant |s1| != 0 && Position >= 1 ==> exists i: int {:trigger a[i]} :: 0 <= i < n1 && a[i] == Element
    invariant 0 <= Count <= n1
    invariant Position >= 1 ==> forall i: int {:trigger a[i]} :: 0 <= i < Count ==> a[i] != Element
    invariant Position == -1 ==> forall i: int {:trigger a[i]} :: 0 <= i < n1 ==> a[i] != Element
    decreases n1 - Count
  {
    if a[n1 - 1 - Count] == Element {
      Position := Count + 1;
      return Position, Count;
    }
    Count := Count + 1;
  }
  assert Position != -1 ==> true;
  Position := -1;
  assert Position == -1;
}

method Main()
{
  var a := new int[5];
  var b := [1, 2, 3, 4];
  a[0], a[1], a[2], a[3] := 1, 2, 3, 4;
  var n1 := |b|;
  var Element := 5;
  var Position, Count;
  Position, Count := FindPositionOfElement(a, Element, n1, b);
  print "position is ", Position;
}
