// Dafny_Verify_tmp_tmphq7j0row_dataset_bql_exampls_Square.dfy

method square(n: int) returns (r: int)
  requires 0 <= n
  ensures r == n * n
  decreases n
{
  var x: int;
  var i: int;
  r := 0;
  i := 0;
  x := 1;
  while i < n
    invariant i <= n
    invariant r == i * i
    invariant x == 2 * i + 1
    decreases n - i
  {
    x := x + 2;
    i := i + 1;
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  0 <= n
  //   POST: r == n * n
  {
    var n := 0;
    expect 0 <= n; // PRE-CHECK
    var r := square(n);
    expect r == 0;
  }

}

method Failing()
{
  // Test case for combination {1}/Bn=1:
  //   PRE:  0 <= n
  //   POST: r == n * n
  {
    var n := 1;
    // expect 0 <= n; // PRE-CHECK
    var r := square(n);
    // expect r == 1;
  }

  // Test case for combination {1}/R3:
  //   PRE:  0 <= n
  //   POST: r == n * n
  {
    var n := 4;
    // expect 0 <= n; // PRE-CHECK
    var r := square(n);
    // expect r == 16;
  }

  // Test case for combination {1}/R4:
  //   PRE:  0 <= n
  //   POST: r == n * n
  {
    var n := 5;
    // expect 0 <= n; // PRE-CHECK
    var r := square(n);
    // expect r == 25;
  }

  // Test case for combination {1}/R5:
  //   PRE:  0 <= n
  //   POST: r == n * n
  {
    var n := 13;
    // expect 0 <= n; // PRE-CHECK
    var r := square(n);
    // expect r == 169;
  }

}

method Main()
{
  Passing();
  Failing();
}
