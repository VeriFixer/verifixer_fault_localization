// dafny-synthesis_task_id_80.dfy

method TetrahedralNumber(n: int) returns (t: int)
  requires n >= 0
  ensures t == n * (n + 1) * (n + 2) / 6
  decreases n
{
  t := n * (n + 1) * (0 + 2) / 6;
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  n >= 0
  //   POST: t == n * (n + 1) * (n + 2) / 6
  {
    var n := 0;
    expect n >= 0; // PRE-CHECK
    var t := TetrahedralNumber(n);
    expect t == 0;
  }

}

method Failing()
{
  // Test case for combination {1}/Bn=1:
  //   PRE:  n >= 0
  //   POST: t == n * (n + 1) * (n + 2) / 6
  {
    var n := 1;
    // expect n >= 0; // PRE-CHECK
    var t := TetrahedralNumber(n);
    // expect t == 1;
  }

  // Test case for combination {1}/R3:
  //   PRE:  n >= 0
  //   POST: t == n * (n + 1) * (n + 2) / 6
  {
    var n := 4;
    // expect n >= 0; // PRE-CHECK
    var t := TetrahedralNumber(n);
    // expect t == 20;
  }

  // Test case for combination {1}/R4:
  //   PRE:  n >= 0
  //   POST: t == n * (n + 1) * (n + 2) / 6
  {
    var n := 5;
    // expect n >= 0; // PRE-CHECK
    var t := TetrahedralNumber(n);
    // expect t == 35;
  }

  // Test case for combination {1}/R5:
  //   PRE:  n >= 0
  //   POST: t == n * (n + 1) * (n + 2) / 6
  {
    var n := 13;
    // expect n >= 0; // PRE-CHECK
    var t := TetrahedralNumber(n);
    // expect t == 455;
  }

}

method Main()
{
  Passing();
  Failing();
}
