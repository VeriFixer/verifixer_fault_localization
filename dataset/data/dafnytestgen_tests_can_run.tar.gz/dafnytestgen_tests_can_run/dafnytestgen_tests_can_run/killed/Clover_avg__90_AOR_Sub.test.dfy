// Clover_avg.dfy

method ComputeAvg(a: int, b: int) returns (avg: int)
  ensures avg == (a + b) / 2
  decreases a, b
{
  avg := (a - b) / 2;
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: avg == (a + b) / 2
  {
    var a := 0;
    var b := 0;
    var avg := ComputeAvg(a, b);
    expect avg == 0;
  }

  // Test case for combination {1}/Ba=1,b=0:
  //   POST: avg == (a + b) / 2
  {
    var a := 1;
    var b := 0;
    var avg := ComputeAvg(a, b);
    expect avg == 0;
  }

}

method Failing()
{
  // Test case for combination {1}/Ba=0,b=1:
  //   POST: avg == (a + b) / 2
  {
    var a := 0;
    var b := 1;
    var avg := ComputeAvg(a, b);
    // expect avg == 0;
  }

  // Test case for combination {1}/Ba=1,b=1:
  //   POST: avg == (a + b) / 2
  {
    var a := 1;
    var b := 1;
    var avg := ComputeAvg(a, b);
    // expect avg == 1;
  }

  // Test case for combination {1}/R5:
  //   POST: avg == (a + b) / 2
  {
    var a := -1;
    var b := -1;
    var avg := ComputeAvg(a, b);
    // expect avg == -1;
  }

}

method Main()
{
  Passing();
  Failing();
}
