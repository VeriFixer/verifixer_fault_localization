// dafny-synthesis_task_id_605.dfy

method IsPrime(n: int) returns (result: bool)
  requires n >= 2
  ensures result <==> forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  decreases n
{
  result := true;
  var i := 0;
  while i <= n / 2
    invariant 2 <= i
    invariant result <==> forall k: int {:trigger n % k} :: 2 <= k < i ==> n % k != 0
    decreases n / 2 - i
  {
    if n % i == 0 {
      result := false;
      break;
    }
    i := i + 1;
  }
}


method Passing()
{
  // (no passing tests)
}

method Failing()
{
  // Test case for combination {1}:
  //   PRE:  n >= 2
  //   POST: result
  //   POST: forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 2;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == true;
    // expect forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {2}:
  //   PRE:  n >= 2
  //   POST: !result
  //   POST: !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 4;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == false;
    // expect !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {1}/Bn=3:
  //   PRE:  n >= 2
  //   POST: result
  //   POST: forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 3;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == true;
    // expect forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {1}/R3:
  //   PRE:  n >= 2
  //   POST: result
  //   POST: forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 5;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == true;
    // expect forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {1}/R4:
  //   PRE:  n >= 2
  //   POST: result
  //   POST: forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 7;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == true;
    // expect forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {1}/R5:
  //   PRE:  n >= 2
  //   POST: result
  //   POST: forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 13;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == true;
    // expect forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {2}/R2:
  //   PRE:  n >= 2
  //   POST: !result
  //   POST: !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 6;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == false;
    // expect !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {2}/R3:
  //   PRE:  n >= 2
  //   POST: !result
  //   POST: !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 9;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == false;
    // expect !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {2}/R4:
  //   PRE:  n >= 2
  //   POST: !result
  //   POST: !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 12;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == false;
    // expect !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

  // Test case for combination {2}/R5:
  //   PRE:  n >= 2
  //   POST: !result
  //   POST: !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0
  {
    var n := 15;
    // expect n >= 2; // PRE-CHECK
    var result := IsPrime(n);
    // expect result == false;
    // expect !forall k: int {:trigger n % k} :: 2 <= k < n ==> n % k != 0;
  }

}

method Main()
{
  Passing();
  Failing();
}
