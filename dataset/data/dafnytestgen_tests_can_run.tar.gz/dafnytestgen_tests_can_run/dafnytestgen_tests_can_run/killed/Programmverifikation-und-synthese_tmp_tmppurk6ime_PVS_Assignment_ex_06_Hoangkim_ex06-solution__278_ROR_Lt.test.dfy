// Programmverifikation-und-synthese_tmp_tmppurk6ime_PVS_Assignment_ex_06_Hoangkim_ex06-solution.dfy

function gcd(x: int, y: int): int
  requires x > 0 && y > 0
  decreases x, y
{
  if x == y then
    x
  else if x > y then
    gcd(x - y, y)
  else
    gcd(x, y - x)
}

method gcdI(m: int, n: int) returns (d: int)
  requires m > 0 && n > 0
  ensures d == gcd(m, n)
  decreases m, n
{
  var x, y := m, n;
  d := 1;
  while x < y
    invariant x > 0 && y > 0
    invariant gcd(x, y) == gcd(m, n)
    decreases x + y
  {
    if x > y {
      x := x - y;
    } else {
      y := y - x;
    }
  }
  d := x;
}

function gcd'(x: int, y: int): int
  requires x > 0 && y > 0
  decreases x + y, y
{
  if x == y then
    x
  else if x > y then
    gcd'(x - y, y)
  else
    gcd'(y, x)
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  m > 0 && n > 0
  //   POST: d == gcd(m, n)
  {
    var m := 1;
    var n := 1;
    expect m > 0 && n > 0; // PRE-CHECK
    var d := gcdI(m, n);
    expect d == 1;
  }

  // Test case for combination {1}/Bm=1,n=2:
  //   PRE:  m > 0 && n > 0
  //   POST: d == gcd(m, n)
  {
    var m := 1;
    var n := 2;
    expect m > 0 && n > 0; // PRE-CHECK
    var d := gcdI(m, n);
    expect d == 1;
  }

  // Test case for combination {1}/Bm=2,n=2:
  //   PRE:  m > 0 && n > 0
  //   POST: d == gcd(m, n)
  {
    var m := 2;
    var n := 2;
    expect m > 0 && n > 0; // PRE-CHECK
    var d := gcdI(m, n);
    expect d == 2;
  }

}

method Failing()
{
  // Test case for combination {1}/Bm=2,n=1:
  //   PRE:  m > 0 && n > 0
  //   POST: d == gcd(m, n)
  {
    var m := 2;
    var n := 1;
    var check_d := gcd(m, n);
    // expect m > 0 && n > 0; // PRE-CHECK
    var d := gcdI(m, n);
    // expect d == check_d;
  }

  // Test case for combination {1}/R5:
  //   PRE:  m > 0 && n > 0
  //   POST: d == gcd(m, n)
  {
    var m := 3;
    var n := 1;
    var check_d := gcd(m, n);
    // expect m > 0 && n > 0; // PRE-CHECK
    var d := gcdI(m, n);
    // expect d == check_d;
  }

}

method Main()
{
  Passing();
  Failing();
}
