// dafny-synthesis_task_id_406.dfy

method IsOdd(n: int) returns (result: bool)
  ensures result <==> n % 2 == 1
  decreases n
{
  result := n + 2 == 1;
}


method Passing()
{
  // Test case for combination {2}:
  //   POST: !result
  //   POST: !(n % 2 == 1)
  {
    var n := 0;
    var result := IsOdd(n);
    expect result == false;
    expect !(n % 2 == 1);
  }

  // Test case for combination {1}/R3:
  //   POST: result
  //   POST: n % 2 == 1
  {
    var n := -1;
    var result := IsOdd(n);
    expect result == true;
    expect n % 2 == 1;
  }

  // Test case for combination {2}/R2:
  //   POST: !result
  //   POST: !(n % 2 == 1)
  {
    var n := -2;
    var result := IsOdd(n);
    expect result == false;
    expect !(n % 2 == 1);
  }

  // Test case for combination {2}/R3:
  //   POST: !result
  //   POST: !(n % 2 == 1)
  {
    var n := -4;
    var result := IsOdd(n);
    expect result == false;
    expect !(n % 2 == 1);
  }

  // Test case for combination {2}/R4:
  //   POST: !result
  //   POST: !(n % 2 == 1)
  {
    var n := -6;
    var result := IsOdd(n);
    expect result == false;
    expect !(n % 2 == 1);
  }

  // Test case for combination {2}/R5:
  //   POST: !result
  //   POST: !(n % 2 == 1)
  {
    var n := 2;
    var result := IsOdd(n);
    expect result == false;
    expect !(n % 2 == 1);
  }

}

method Failing()
{
  // Test case for combination {1}:
  //   POST: result
  //   POST: n % 2 == 1
  {
    var n := 1;
    var result := IsOdd(n);
    // expect result == true;
    // expect n % 2 == 1;
  }

  // Test case for combination {1}/R2:
  //   POST: result
  //   POST: n % 2 == 1
  {
    var n := 3;
    var result := IsOdd(n);
    // expect result == true;
    // expect n % 2 == 1;
  }

  // Test case for combination {1}/R4:
  //   POST: result
  //   POST: n % 2 == 1
  {
    var n := 5;
    var result := IsOdd(n);
    // expect result == true;
    // expect n % 2 == 1;
  }

  // Test case for combination {1}/R5:
  //   POST: result
  //   POST: n % 2 == 1
  {
    var n := -3;
    var result := IsOdd(n);
    // expect result == true;
    // expect n % 2 == 1;
  }

}

method Main()
{
  Passing();
  Failing();
}
