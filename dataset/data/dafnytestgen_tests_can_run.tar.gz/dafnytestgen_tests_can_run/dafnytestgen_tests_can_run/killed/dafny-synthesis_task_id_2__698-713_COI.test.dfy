// dafny-synthesis_task_id_2.dfy

predicate InArray(a: array<int>, x: int)
  reads a
  decreases {a}, a, x
{
  exists i: int {:trigger a[i]} :: 
    0 <= i < a.Length &&
    a[i] == x
}

method SharedElements(a: array<int>, b: array<int>) returns (result: seq<int>)
  ensures forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  ensures forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  decreases a, b
{
  var res: seq<int> := [];
  for i: int := 0 to a.Length
    invariant 0 <= i <= a.Length
    invariant forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in res} :: (x in res ==> InArray(a, x)) && (x in res ==> InArray(b, x))
    invariant forall i: int, j: int {:trigger res[j], res[i]} :: 0 <= i < j < |res| ==> res[i] != res[j]
  {
    if !InArray(b, a[i]) && a[i] !in res {
      res := res + [a[i]];
    }
  }
  result := res;
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[0] [];
    var b := new int[0] [];
    var result := SharedElements(a, b);
    expect result == [];
  }

  // Test case for combination {1}/Ba=0,b=3:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[0] [];
    var b := new int[3] [5, 4, 6];
    var result := SharedElements(a, b);
    expect result == [];
  }

  // Test case for combination {1}/Ba=0,b=2:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[0] [];
    var b := new int[2] [4, 3];
    var result := SharedElements(a, b);
    expect result == [];
  }

  // Test case for combination {1}/Ba=0,b=1:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[0] [];
    var b := new int[1] [2];
    var result := SharedElements(a, b);
    expect result == [];
  }

}

method Failing()
{
  // Test case for combination {1}/Ba=3,b=1:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[3] [5, 4, 6];
    var b := new int[1] [13];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=3,b=0:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[3] [5, 4, 6];
    var b := new int[0] [];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=2,b=3:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[2] [5, 4];
    var b := new int[3] [7, 6, 8];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=2,b=2:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[2] [4, 3];
    var b := new int[2] [6, 5];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=2,b=1:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[2] [4, 3];
    var b := new int[1] [8];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=2,b=0:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[2] [4, 3];
    var b := new int[0] [];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=3,b=2:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[3] [5, 4, 6];
    var b := new int[2] [8, 7];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=1,b=3:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[1] [13];
    var b := new int[3] [5, 4, 6];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=1,b=1:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[1] [2];
    var b := new int[1] [3];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=1,b=0:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[1] [2];
    var b := new int[0] [];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=1,b=2:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[1] [8];
    var b := new int[2] [4, 3];
    var result := SharedElements(a, b);
    // expect result == [];
  }

  // Test case for combination {1}/Ba=3,b=3:
  //   POST: forall x: int {:trigger InArray(b, x)} {:trigger InArray(a, x)} {:trigger x in result} :: (x in result ==> InArray(a, x)) && (x in result ==> InArray(b, x))
  //   POST: forall i: int, j: int {:trigger result[j], result[i]} :: 0 <= i < j < |result| ==> result[i] != result[j]
  {
    var a := new int[3] [5, 4, 6];
    var b := new int[3] [8, 7, 9];
    var result := SharedElements(a, b);
    // expect result == [];
  }

}

method Main()
{
  Passing();
  Failing();
}
