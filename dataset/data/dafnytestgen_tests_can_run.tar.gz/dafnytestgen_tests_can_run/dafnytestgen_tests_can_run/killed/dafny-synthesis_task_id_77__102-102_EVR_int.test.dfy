// dafny-synthesis_task_id_77.dfy

method IsDivisibleBy11(n: int) returns (result: bool)
  ensures result <==> n % 11 == 0
  decreases n
{
  result := 0 % 11 == 0;
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: result
  //   POST: n % 11 == 0
  {
    var n := 0;
    var result := IsDivisibleBy11(n);
    expect result == true;
    expect n % 11 == 0;
  }

  // Test case for combination {1}/R2:
  //   POST: result
  //   POST: n % 11 == 0
  {
    var n := 11;
    var result := IsDivisibleBy11(n);
    expect result == true;
    expect n % 11 == 0;
  }

  // Test case for combination {1}/R3:
  //   POST: result
  //   POST: n % 11 == 0
  {
    var n := -11;
    var result := IsDivisibleBy11(n);
    expect result == true;
    expect n % 11 == 0;
  }

  // Test case for combination {1}/R4:
  //   POST: result
  //   POST: n % 11 == 0
  {
    var n := 22;
    var result := IsDivisibleBy11(n);
    expect result == true;
    expect n % 11 == 0;
  }

  // Test case for combination {1}/R5:
  //   POST: result
  //   POST: n % 11 == 0
  {
    var n := -22;
    var result := IsDivisibleBy11(n);
    expect result == true;
    expect n % 11 == 0;
  }

}

method Failing()
{
  // Test case for combination {2}:
  //   POST: !result
  //   POST: !(n % 11 == 0)
  {
    var n := 1;
    var result := IsDivisibleBy11(n);
    // expect result == false;
    // expect !(n % 11 == 0);
  }

  // Test case for combination {2}/R2:
  //   POST: !result
  //   POST: !(n % 11 == 0)
  {
    var n := -1;
    var result := IsDivisibleBy11(n);
    // expect result == false;
    // expect !(n % 11 == 0);
  }

  // Test case for combination {2}/R3:
  //   POST: !result
  //   POST: !(n % 11 == 0)
  {
    var n := -2;
    var result := IsDivisibleBy11(n);
    // expect result == false;
    // expect !(n % 11 == 0);
  }

  // Test case for combination {2}/R4:
  //   POST: !result
  //   POST: !(n % 11 == 0)
  {
    var n := -3;
    var result := IsDivisibleBy11(n);
    // expect result == false;
    // expect !(n % 11 == 0);
  }

  // Test case for combination {2}/R5:
  //   POST: !result
  //   POST: !(n % 11 == 0)
  {
    var n := 2;
    var result := IsDivisibleBy11(n);
    // expect result == false;
    // expect !(n % 11 == 0);
  }

}

method Main()
{
  Passing();
  Failing();
}
