// Clover_set_to_seq.dfy

method SetToSeq<T>(s: set<T>) returns (xs: seq<T>)
  ensures multiset(s) == multiset(xs)
  decreases s
{
  xs := [];
  var left: set<T> := s;
  while left != {}
    invariant multiset(left) + multiset(xs) == multiset(s)
    decreases left
  {
    var x :| x in left;
    left := left - {x};
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: multiset(s) == multiset(xs)
  {
    var s: set<int> := {};
    var xs := SetToSeq<int>(s);
    expect xs == [];
  }

  // Test case for combination {1}/Bs=1:
  //   POST: multiset(s) == multiset(xs)
  {
    var s: set<int> := {3};
    var xs := SetToSeq<int>(s);
    expect xs == [];
  }

  // Test case for combination {1}/Bs=2:
  //   POST: multiset(s) == multiset(xs)
  {
    var s: set<int> := {-1, 5};
    var xs := SetToSeq<int>(s);
    expect xs == [];
  }

  // Test case for combination {1}/Bs=3:
  //   POST: multiset(s) == multiset(xs)
  {
    var s: set<int> := {3, 4, 5};
    var xs := SetToSeq<int>(s);
    expect xs == [];
  }

  // Test case for combination {1}/R5:
  //   POST: multiset(s) == multiset(xs)
  {
    var s: set<int> := {-1, 0, 1, 4};
    var xs := SetToSeq<int>(s);
    expect xs == [];
  }

}

method Failing()
{
  // (no failing tests)
}

method Main()
{
  Passing();
  Failing();
}
