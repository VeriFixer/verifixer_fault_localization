// dafny-language-server_tmp_tmpkir0kenl_Test_comp_Arrays.dfy

method LinearSearch(a: array<int>, key: int) returns (n: nat)
  ensures 0 <= n <= a.Length
  ensures n == a.Length || a[n] == key
  decreases a, key
{
  n := 0;
  while n < a.Length
    invariant n <= a.Length
    decreases a.Length - n
  {
    if a[n] == key {
      return;
    }
    n := n + 1;
  }
}

method PrintArray<A>(a: array?<A>)
  decreases a
{
  if a == null {
    print "It's null\n";
  } else {
    var i := 0;
    while i < a.Length
      decreases a.Length - i
    {
      print a[i], " ";
      i := i + 1;
    }
    print "\n";
  }
}

method OriginalMain()
{
  var a := new int[23];
  var i := 0;
  while i < 23
    decreases 23 - i
  {
    a[i] := i;
    i := i + 1;
  }
  PrintArray(a);
  var n := LinearSearch(a, 17);
  print n, "\n";
  var s: seq<int> := a[..];
  print s, "\n";
  s := a[2 .. 16];
  print s, "\n";
  s := a[20..];
  print s, "\n";
  s := a[..8];
  print s, "\n";
  a[0] := 42;
  print s, "\n";
  InitTests();
  MultipleDimensions();
  PrintArray<int>(null);
}

method InitTests()
{
  var aa := new lowercase[3];
  PrintArray(aa);
  var s := "hello";
  aa := new lowercase[|s|] ((i: int) requires 0 <= i < |s| => s[i]);
  PrintArray(aa);
}

method MultipleDimensions()
{
  var matrix := new int[2, 8];
  PrintMatrix(matrix);
  matrix := DiagMatrix(3, 5, 0, 1);
  PrintMatrix(matrix);
  var cube := new int[3, 0, 4] ((_ /* _v0 */: nat, _ /* _v1 */: int, _ /* _v2 */: int) => 16);
  print "cube dims: ", cube.Length0, " ", cube.Length1, " ", cube.Length2, "\n";
}

method DiagMatrix<A>(rows: int, cols: int, zero: A, one: A)
    returns (a: array2<A>)
  requires rows >= 0 && cols >= 0
  decreases rows, cols
{
  return new A[rows, cols] ((x: nat, y: int) => if x == y then one else zero);
}

method PrintMatrix<A>(m: array2<A>)
  decreases m
{
  var i := 0;
  while i < m.Length0
    decreases m.Length0 - i
  {
    var j := 0;
    while j < m.Length1
      decreases m.Length1 - j
    {
      print m[i, j], " ";
      j := j + 1;
    }
    print "\n";
    i := j + 1;
  }
}

type lowercase = ch: char
  | 'a' <= ch <= 'z'
  witness 'd'


method Passing()
{
  // Test case for combination {1}:
  //   POST: 0 <= n <= a.Length
  //   POST: n == a.Length
  {
    var a := new int[0] [];
    var key := 0;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

  // Test case for combination {2}:
  //   POST: 0 <= n <= a.Length
  //   POST: a[n] == key
  {
    var a := new int[1] [4];
    var key := 4;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

  // Test case for combination {1}/Ba=0,key=1:
  //   POST: 0 <= n <= a.Length
  //   POST: n == a.Length
  {
    var a := new int[0] [];
    var key := 1;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

  // Test case for combination {1}/Ba=1,key=0:
  //   POST: 0 <= n <= a.Length
  //   POST: n == a.Length
  {
    var a := new int[1] [2];
    var key := 0;
    var n := LinearSearch(a, key);
    expect n == 1;
  }

  // Test case for combination {1}/Ba=1,key=1:
  //   POST: 0 <= n <= a.Length
  //   POST: n == a.Length
  {
    var a := new int[1] [2];
    var key := 1;
    var n := LinearSearch(a, key);
    expect n == 1;
  }

  // Test case for combination {1}/Ba=2,key=0:
  //   POST: 0 <= n <= a.Length
  //   POST: n == a.Length
  {
    var a := new int[2] [4, 3];
    var key := 0;
    var n := LinearSearch(a, key);
    expect n == 2;
  }

  // Test case for combination {1}/Ba=2,key=1:
  //   POST: 0 <= n <= a.Length
  //   POST: n == a.Length
  {
    var a := new int[2] [4, 3];
    var key := 1;
    var n := LinearSearch(a, key);
    expect n == 2;
  }

  // Test case for combination {1}/Ba=3,key=0:
  //   POST: 0 <= n <= a.Length
  //   POST: n == a.Length
  {
    var a := new int[3] [5, 4, 6];
    var key := 0;
    var n := LinearSearch(a, key);
    expect n == 3;
  }

  // Test case for combination {1}/Ba=3,key=1:
  //   POST: 0 <= n <= a.Length
  //   POST: n == a.Length
  {
    var a := new int[3] [5, 4, 6];
    var key := 1;
    var n := LinearSearch(a, key);
    expect n == 3;
  }

  // Test case for combination {2}/Ba=3,key=1:
  //   POST: 0 <= n <= a.Length
  //   POST: a[n] == key
  {
    var a := new int[3] [1, 6, 7];
    var key := 1;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

  // Test case for combination {2}/Ba=3,key=0:
  //   POST: 0 <= n <= a.Length
  //   POST: a[n] == key
  {
    var a := new int[3] [0, 6, 7];
    var key := 0;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

  // Test case for combination {2}/Ba=2,key=1:
  //   POST: 0 <= n <= a.Length
  //   POST: a[n] == key
  {
    var a := new int[2] [1, 5];
    var key := 1;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

  // Test case for combination {2}/Ba=2,key=0:
  //   POST: 0 <= n <= a.Length
  //   POST: a[n] == key
  {
    var a := new int[2] [0, 5];
    var key := 0;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

  // Test case for combination {2}/Ba=1,key=1:
  //   POST: 0 <= n <= a.Length
  //   POST: a[n] == key
  {
    var a := new int[1] [1];
    var key := 1;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

  // Test case for combination {2}/Ba=1,key=0:
  //   POST: 0 <= n <= a.Length
  //   POST: a[n] == key
  {
    var a := new int[1] [0];
    var key := 0;
    var n := LinearSearch(a, key);
    expect n == 0;
  }

}

method Failing()
{
  // (no failing tests)
}

method Main()
{
  Passing();
  Failing();
}
