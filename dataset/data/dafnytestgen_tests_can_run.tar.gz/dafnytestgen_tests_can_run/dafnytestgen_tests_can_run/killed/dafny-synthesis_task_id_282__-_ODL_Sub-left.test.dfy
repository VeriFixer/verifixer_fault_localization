// dafny-synthesis_task_id_282.dfy

method ElementWiseSubtraction(a: array<int>, b: array<int>) returns (result: array<int>)
  requires a != null && b != null
  requires a.Length == b.Length
  ensures result != null
  ensures result.Length == a.Length
  ensures forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i]
  decreases a, b
{
  result := new int[a.Length];
  var i := 0;
  while i < a.Length
    invariant 0 <= i <= a.Length
    invariant result.Length == a.Length
    invariant forall k: int {:trigger b[k]} {:trigger a[k]} {:trigger result[k]} :: 0 <= k < i ==> result[k] == a[k] - b[k]
    decreases a.Length - i
  {
    result[i] := b[i];
    i := i + 1;
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  a != null && b != null
  //   PRE:  a.Length == b.Length
  //   POST: result != null
  //   POST: result.Length == a.Length
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i]
  {
    var a := new int[0] [];
    var b := new int[0] [];
    expect a != null && b != null; // PRE-CHECK
    expect a.Length == b.Length; // PRE-CHECK
    var result := ElementWiseSubtraction(a, b);
    expect result != null;
    expect result.Length == a.Length;
    expect forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i];
  }

}

method Failing()
{
  // Test case for combination {1}/Ba=2,b=2:
  //   PRE:  a != null && b != null
  //   PRE:  a.Length == b.Length
  //   POST: result != null
  //   POST: result.Length == a.Length
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i]
  {
    var a := new int[2] [4, 3];
    var b := new int[2] [6, 5];
    // expect a != null && b != null; // PRE-CHECK
    // expect a.Length == b.Length; // PRE-CHECK
    var result := ElementWiseSubtraction(a, b);
    // expect result != null;
    // expect result.Length == a.Length;
    // expect forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i];
  }

  // Test case for combination {1}/Ba=1,b=1:
  //   PRE:  a != null && b != null
  //   PRE:  a.Length == b.Length
  //   POST: result != null
  //   POST: result.Length == a.Length
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i]
  {
    var a := new int[1] [2];
    var b := new int[1] [3];
    // expect a != null && b != null; // PRE-CHECK
    // expect a.Length == b.Length; // PRE-CHECK
    var result := ElementWiseSubtraction(a, b);
    // expect result != null;
    // expect result.Length == a.Length;
    // expect forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i];
  }

  // Test case for combination {1}/Ba=3,b=3:
  //   PRE:  a != null && b != null
  //   PRE:  a.Length == b.Length
  //   POST: result != null
  //   POST: result.Length == a.Length
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i]
  {
    var a := new int[3] [5, 4, 6];
    var b := new int[3] [8, 7, 9];
    // expect a != null && b != null; // PRE-CHECK
    // expect a.Length == b.Length; // PRE-CHECK
    var result := ElementWiseSubtraction(a, b);
    // expect result != null;
    // expect result.Length == a.Length;
    // expect forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i];
  }

  // Test case for combination {1}/R5:
  //   PRE:  a != null && b != null
  //   PRE:  a.Length == b.Length
  //   POST: result != null
  //   POST: result.Length == a.Length
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i]
  {
    var a := new int[4] [7, 8, 9, 10];
    var b := new int[4] [21, 22, 23, 24];
    // expect a != null && b != null; // PRE-CHECK
    // expect a.Length == b.Length; // PRE-CHECK
    var result := ElementWiseSubtraction(a, b);
    // expect result != null;
    // expect result.Length == a.Length;
    // expect forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < result.Length ==> result[i] == a[i] - b[i];
  }

}

method Main()
{
  Passing();
  Failing();
}
