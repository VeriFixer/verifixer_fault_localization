// dafny_examples_tmp_tmp8qotd4ez_leetcode_0069-sqrt.dfy

predicate sqrt(x: int, r: int)
  decreases x, r
{
  r * r <= x &&
  (r + 1) * (r + 1) > x
}

lemma uniqueSqrt(x: int, r1: int, r2: int)
  requires x >= 0 && r1 >= 0 && r2 >= 0
  ensures sqrt(x, r1) && sqrt(x, r2) ==> r1 == r2
  decreases x, r1, r2
{
}

method mySqrt(x: int) returns (res: int)
  requires 0 <= x
  ensures sqrt(x, res)
  decreases x
{
  var l, r := 0, x;
  while l <= r
    invariant l >= 0
    invariant r >= 0
    invariant l * l <= x
    invariant (r + 1) * (r + 1) > x
    decreases r - l
  {
    var mid := (l + r) / 2;
    if mid * mid <= x && mid + 1 - (mid + 1) > x {
      return mid;
    } else if mid * mid <= x {
      l := mid + 1;
    } else {
      r := mid - 1;
    }
  }
}


method Passing()
{
  // Test case for combination {1}/Bx=0:
  //   PRE:  0 <= x
  //   POST: sqrt(x, res)
  {
    var x := 0;
    expect 0 <= x; // PRE-CHECK
    var res := mySqrt(x);
    expect res == 0;
  }

}

method Failing()
{
  // Test case for combination {1}:
  //   PRE:  0 <= x
  //   POST: sqrt(x, res)
  {
    var x := 7;
    // expect 0 <= x; // PRE-CHECK
    var res := mySqrt(x);
    // expect res == 2;
  }

  // Test case for combination {1}/Bx=1:
  //   PRE:  0 <= x
  //   POST: sqrt(x, res)
  {
    var x := 1;
    // expect 0 <= x; // PRE-CHECK
    var res := mySqrt(x);
    // expect res == 1;
  }

  // Test case for combination {1}/R4:
  //   PRE:  0 <= x
  //   POST: sqrt(x, res)
  {
    var x := 5;
    // expect 0 <= x; // PRE-CHECK
    var res := mySqrt(x);
    // expect res == 2;
  }

  // Test case for combination {1}/R5:
  //   PRE:  0 <= x
  //   POST: sqrt(x, res)
  {
    var x := 6;
    // expect 0 <= x; // PRE-CHECK
    var res := mySqrt(x);
    // expect res == 2;
  }

}

method Main()
{
  Passing();
  Failing();
}
