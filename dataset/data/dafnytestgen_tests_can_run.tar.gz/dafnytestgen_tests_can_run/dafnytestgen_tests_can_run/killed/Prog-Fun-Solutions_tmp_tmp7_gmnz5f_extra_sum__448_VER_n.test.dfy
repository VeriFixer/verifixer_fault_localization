// Prog-Fun-Solutions_tmp_tmp7_gmnz5f_extra_sum.dfy

function sum(n: nat): int
  decreases n
{
  if n == 0 then
    0
  else
    n + sum(n - 1)
}

method Sum(n: nat) returns (s: int)
  ensures s == sum(n)
  decreases n
{
  var x: nat := 0;
  var y: nat := 1;
  var k: nat := n;
  while k > 0
    invariant sum(n) == x + y * sum(k)
    invariant 0 <= k <= n
    decreases k
  {
    assert sum(n) == x + y * sum(k);
    assert sum(n) == x + y * (k + sum(k - 1));
    assert sum(n) == x + y * k + y * sum(k - 1);
    x := x + n * k;
    assert sum(n) == x + y * sum(k - 1);
    assert sum(n) == x + y * sum(k - 1);
    k := k - 1;
    assert sum(n) == x + y * sum(k);
  }
  assert k == 0;
  assert sum(n) == x + y * sum(0);
  assert sum(n) == x + y * 0;
  s := x;
  assert sum(n) == s;
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: s == sum(n)
  {
    var n := 0;
    var s := Sum(n);
    expect s == 0;
  }

  // Test case for combination {1}/Bn=1:
  //   POST: s == sum(n)
  {
    var n := 1;
    var s := Sum(n);
    expect s == 1;
  }

}

method Failing()
{
  // Test case for combination {1}/R3:
  //   POST: s == sum(n)
  {
    var n := 2;
    var check_s := sum(n);
    var s := Sum(n);
    // expect s == check_s;
  }

  // Test case for combination {1}/R4:
  //   POST: s == sum(n)
  {
    var n := 3;
    var check_s := sum(n);
    var s := Sum(n);
    // expect s == check_s;
  }

  // Test case for combination {1}/R5:
  //   POST: s == sum(n)
  {
    var n := 4;
    var check_s := sum(n);
    var s := Sum(n);
    // expect s == check_s;
  }

}

method Main()
{
  Passing();
  Failing();
}
