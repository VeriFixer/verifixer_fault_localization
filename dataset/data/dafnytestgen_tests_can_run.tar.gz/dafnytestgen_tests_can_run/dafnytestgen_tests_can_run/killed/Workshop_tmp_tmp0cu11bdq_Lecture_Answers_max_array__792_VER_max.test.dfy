// Workshop_tmp_tmp0cu11bdq_Lecture_Answers_max_array.dfy

method max(a: array<int>) returns (max: int)
  requires a != null
  ensures forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  ensures a.Length > 0 ==> exists j: int {:trigger a[j]} :: j >= 0 && j < a.Length && max == a[j]
  decreases a
{
  if a.Length == 0 {
    max := 0;
    return;
  }
  max := a[0];
  var i := 1;
  while i < a.Length
    invariant i <= a.Length
    invariant forall j: int {:trigger a[j]} :: 0 <= j < i ==> max >= a[j]
    invariant exists j: int {:trigger a[j]} :: 0 <= j < i && max == a[j]
    decreases a.Length - i
  {
    if a[max] > max {
      max := a[i];
    }
    i := i + 1;
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: !(a.Length > 0)
  {
    var a := new int[0] [];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
    expect !(a.Length > 0);
  }

  // Test case for combination {2,3}:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[3] [0, 0, -1];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,4}:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[1] [38];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 38;
  }

  // Test case for combination {2,3,4}:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[3] [0, 0, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,3}/R2:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[4] [0, 0, -38, -1];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,3}/R3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[8] [0, 0, -38, -7719, -21238, -2437, -8855, -1];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,3}/R4:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[7] [0, 0, -38, -7719, -21238, -2437, -1];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,3}/R5:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[6] [0, 0, -38, -7719, -21238, -1];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,4}/R2:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[2] [0, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,4}/R3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[3] [0, -1, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,4}/R4:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[4] [0, -1, -39, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,4}/R5:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[5] [0, -1, -39, -7720, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,3,4}/R2:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[4] [0, 0, -38, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,3,4}/R3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[8] [0, -38, 0, -7719, -21238, -2437, -8855, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,3,4}/R4:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[7] [0, 0, -38, -7719, -21238, -2437, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

  // Test case for combination {2,3,4}/R5:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[6] [0, 0, -38, -7719, -21238, 0];
    expect a != null; // PRE-CHECK
    var max := max(a);
    expect max == 0;
  }

}

method Failing()
{
  // Test case for combination {2}:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  {
    var a := new int[2] [38, 37];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 38;
  }

  // Test case for combination {3}:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[4] [-1, 0, 0, -39];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 0;
  }

  // Test case for combination {4}:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[2] [28957, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

  // Test case for combination {2}/Ba=3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  {
    var a := new int[3] [38, 36, 37];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 38;
  }

  // Test case for combination {3}/Ba=3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[3] [36, 38, 37];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 38;
  }

  // Test case for combination {4}/Ba=3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[3] [36, 37, 38];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 38;
  }

  // Test case for combination {3,4}:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[4] [28957, 28958, 28958, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

  // Test case for combination {2}/R3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  {
    var a := new int[4] [38, 37, 37, 37];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 38;
  }

  // Test case for combination {2}/R4:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  {
    var a := new int[5] [23676, 15956, 23675, 23675, 23675];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 23676;
  }

  // Test case for combination {2}/R5:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[0]
  {
    var a := new int[6] [38, 37, 37, 37, 37, 37];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 38;
  }

  // Test case for combination {3}/R3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[8] [-1, 0, 0, 0, 0, 0, 0, -39];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 0;
  }

  // Test case for combination {3}/R4:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[7] [-1, 0, 0, 0, 0, 0, -39];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 0;
  }

  // Test case for combination {3}/R5:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  {
    var a := new int[6] [-1, 0, 0, 0, 0, -39];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 0;
  }

  // Test case for combination {4}/R3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[4] [28957, -2437, -8855, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

  // Test case for combination {4}/R4:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[7] [28957, -2437, -8855, -11797, -8365, -32285, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

  // Test case for combination {4}/R5:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[6] [28957, -2437, -8855, -11797, -8365, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

  // Test case for combination {3,4}/R2:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[3] [28957, 28958, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

  // Test case for combination {3,4}/R3:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[8] [28957, 28958, 28958, 28958, 28958, -2437, 28958, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

  // Test case for combination {3,4}/R4:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[7] [28957, 28958, -2437, 28958, 28958, 28958, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

  // Test case for combination {3,4}/R5:
  //   PRE:  a != null
  //   POST: forall j: int {:trigger a[j]} :: j >= 0 && j < a.Length ==> max >= a[j]
  //   POST: exists j :: 1 <= j < (a.Length - 1) && max == a[j]
  //   POST: max == a[(a.Length - 1)]
  {
    var a := new int[6] [28957, 28958, 28958, 28958, 28958, 28958];
    // expect a != null; // PRE-CHECK
    var max := max(a);
    // expect max == 28958;
  }

}

method Main()
{
  Passing();
  Failing();
}
