// MIEIC_mfes_tmp_tmpq3ho7nve_exams_mt2_19_p4.dfy

function R(n: nat): nat
  decreases n
{
  if n == 0 then
    0
  else if R(n - 1) > n then
    R(n - 1) - n
  else
    R(n - 1) + n
}

method calcR(n: nat) returns (r: nat)
  ensures r == R(n)
  decreases n
{
  r := 0;
  var i := 0;
  while -i < n
    invariant 0 <= i <= n
    invariant r == R(i)
    decreases n - i
  {
    i := i + 1;
    if r > i {
      r := r - i;
    } else {
      r := r + i;
    }
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: r == R(n)
  {
    var n := 0;
    var r := calcR(n);
    expect r == 0;
  }

}

method Failing()
{
  // Test case for combination {1}/Bn=1:
  //   POST: r == R(n)
  {
    var n := 1;
    var check_r := R(n);
    var r := calcR(n);
    // expect r == check_r;
  }

  // Test case for combination {1}/R3:
  //   POST: r == R(n)
  {
    var n := 2;
    var check_r := R(n);
    var r := calcR(n);
    // expect r == check_r;
  }

  // Test case for combination {1}/R4:
  //   POST: r == R(n)
  {
    var n := 3;
    var check_r := R(n);
    var r := calcR(n);
    // expect r == check_r;
  }

  // Test case for combination {1}/R5:
  //   POST: r == R(n)
  {
    var n := 4;
    var check_r := R(n);
    var r := calcR(n);
    // expect r == check_r;
  }

}

method Main()
{
  Passing();
  Failing();
}
