// Prog-Fun-Solutions_tmp_tmp7_gmnz5f_mockExam2_p5.dfy

function f(n: int): int
  decreases n
{
  if n < 0 then
    0
  else
    3 * f(n - 5) + n
}

method problem5(n: nat) returns (x: int)
  ensures x == f(n)
  decreases n
{
  var a := 1;
  var b := 0;
  var k := n;
  while k >= 0
    invariant f(n) == a * f(k) + b
    invariant -5 <= k <= n
    decreases k
  {
    assert f(n) == a * f(k) + b;
    assert f(n) == a * (3 * f(k - 5) + k) + b;
    assert f(n) == 3 * a * f(k - 5) + a * k + b;
    b := a * k + b;
    assert f(n) == 3 * a * f(k - 5) + b;
    a := 3 * k;
    assert f(n) == a * f(k - 5) + b;
    k := k - 5;
    assert f(n) == a * f(k) + b;
  }
  assert k < 0;
  assert f(n) == a * f(k) + b;
  assert f(n) == a * 0 + b;
  x := b;
  assert x == f(n);
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: x == f(n)
  {
    var n := 0;
    var x := problem5(n);
    expect x == 0;
  }

  // Test case for combination {1}/Bn=1:
  //   POST: x == f(n)
  {
    var n := 1;
    var x := problem5(n);
    expect x == 1;
  }

  // Test case for combination {1}/R3:
  //   POST: x == f(n)
  {
    var n := 2;
    var x := problem5(n);
    expect x == 2;
  }

  // Test case for combination {1}/R4:
  //   POST: x == f(n)
  {
    var n := 3;
    var x := problem5(n);
    expect x == 3;
  }

  // Test case for combination {1}/R5:
  //   POST: x == f(n)
  {
    var n := 4;
    var x := problem5(n);
    expect x == 4;
  }

}

method Failing()
{
  // (no failing tests)
}

method Main()
{
  Passing();
  Failing();
}
