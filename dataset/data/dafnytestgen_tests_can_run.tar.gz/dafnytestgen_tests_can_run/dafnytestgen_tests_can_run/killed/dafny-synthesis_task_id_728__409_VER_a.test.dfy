// dafny-synthesis_task_id_728.dfy

method AddLists(a: seq<int>, b: seq<int>) returns (result: seq<int>)
  requires |a| == |b|
  ensures |result| == |a|
  ensures forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < |result| ==> result[i] == a[i] + b[i]
  decreases a, b
{
  result := [];
  for i: int := 0 to |a|
    invariant 0 <= i <= |a|
    invariant |result| == i
    invariant forall k: int {:trigger b[k]} {:trigger a[k]} {:trigger result[k]} :: 0 <= k < i ==> result[k] == a[k] + b[k]
  {
    result := result + [a[i] + a[i]];
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  |a| == |b|
  //   POST: |result| == |a|
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < |result| ==> result[i] == a[i] + b[i]
  {
    var a: seq<int> := [];
    var b: seq<int> := [];
    expect |a| == |b|; // PRE-CHECK
    var result := AddLists(a, b);
    expect result == [];
  }

  // Test case for combination {1}/Ba=1,b=1:
  //   PRE:  |a| == |b|
  //   POST: |result| == |a|
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < |result| ==> result[i] == a[i] + b[i]
  {
    var a: seq<int> := [0];
    var b: seq<int> := [0];
    expect |a| == |b|; // PRE-CHECK
    var result := AddLists(a, b);
    expect result == [0];
  }

  // Test case for combination {1}/R5:
  //   PRE:  |a| == |b|
  //   POST: |result| == |a|
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < |result| ==> result[i] == a[i] + b[i]
  {
    var a: seq<int> := [0, 0, 0, 0];
    var b: seq<int> := [0, 0, 0, 0];
    expect |a| == |b|; // PRE-CHECK
    var result := AddLists(a, b);
    expect result == [0, 0, 0, 0];
  }

}

method Failing()
{
  // Test case for combination {1}/Ba=2,b=2:
  //   PRE:  |a| == |b|
  //   POST: |result| == |a|
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < |result| ==> result[i] == a[i] + b[i]
  {
    var a: seq<int> := [0, 21239];
    var b: seq<int> := [0, 7720];
    // expect |a| == |b|; // PRE-CHECK
    var result := AddLists(a, b);
    // expect result == [0, 28959];
  }

  // Test case for combination {1}/Ba=3,b=3:
  //   PRE:  |a| == |b|
  //   POST: |result| == |a|
  //   POST: forall i: int {:trigger b[i]} {:trigger a[i]} {:trigger result[i]} :: 0 <= i < |result| ==> result[i] == a[i] + b[i]
  {
    var a: seq<int> := [-10158, -2438, 0];
    var b: seq<int> := [-21240, -21239, 0];
    // expect |a| == |b|; // PRE-CHECK
    var result := AddLists(a, b);
    // expect result == [-31398, -23677, 0];
  }

}

method Main()
{
  Passing();
  Failing();
}
