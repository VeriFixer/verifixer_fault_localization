// Workshop_tmp_tmp0cu11bdq_Workshop_Answers_Question5.dfy

method rev(a: array<int>)
  requires a != null
  modifies a
  ensures forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old(a[a.Length - 1 - k])
  decreases a
{
  var i := 0;
  while i < -(a.Length - 1) - i
    invariant 0 <= i <= a.Length / 2
    invariant forall k: int {:trigger a[k]} :: 0 <= k < i || a.Length - 1 - i < k <= a.Length - 1 ==> a[k] == old(a[a.Length - 1 - k])
    invariant forall k: int {:trigger old(a[k])} {:trigger a[k]} :: i <= k <= a.Length - 1 - i ==> a[k] == old(a[k])
    decreases -(a.Length - 1) - i - i
  {
    a[i], a[a.Length - 1 - i] := a[a.Length - 1 - i], a[i];
    i := i + 1;
  }
}


method Passing()
{
  // Test case for combination {1}/Ba=1:
  //   PRE:  a != null
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old(a[a.Length - 1 - k])
  {
    var a := new int[1] [2];
    var old_a := a[..];
    expect a != null; // PRE-CHECK
    rev(a);
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old_a[a.Length - 1 - k];
  }

}

method Failing()
{
  // Test case for combination {1}:
  //   PRE:  a != null
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old(a[a.Length - 1 - k])
  {
    var a := new int[0] [];
    var old_a := a[..];
    // expect a != null; // PRE-CHECK
    rev(a);
    // expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old_a[a.Length - 1 - k];
  }

  // Test case for combination {1}/Ba=2:
  //   PRE:  a != null
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old(a[a.Length - 1 - k])
  {
    var a := new int[2] [4, 3];
    var old_a := a[..];
    // expect a != null; // PRE-CHECK
    rev(a);
    // expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old_a[a.Length - 1 - k];
  }

  // Test case for combination {1}/Ba=3:
  //   PRE:  a != null
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old(a[a.Length - 1 - k])
  {
    var a := new int[3] [6, 5, 4];
    var old_a := a[..];
    // expect a != null; // PRE-CHECK
    rev(a);
    // expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old_a[a.Length - 1 - k];
  }

  // Test case for combination {1}/R5:
  //   PRE:  a != null
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old(a[a.Length - 1 - k])
  {
    var a := new int[4] [17, 14, 11, 8];
    var old_a := a[..];
    // expect a != null; // PRE-CHECK
    rev(a);
    // expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] == old_a[a.Length - 1 - k];
  }

}

method Main()
{
  Passing();
  Failing();
}
