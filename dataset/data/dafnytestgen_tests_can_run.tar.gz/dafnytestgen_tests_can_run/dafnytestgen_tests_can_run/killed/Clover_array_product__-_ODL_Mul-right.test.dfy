// Clover_array_product.dfy

method arrayProduct(a: array<int>, b: array<int>) returns (c: array<int>)
  requires a.Length == b.Length
  ensures c.Length == a.Length
  ensures forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i]
  decreases a, b
{
  c := new int[a.Length];
  var i := 0;
  while i < a.Length
    invariant 0 <= i <= a.Length
    invariant forall j: int {:trigger c[j]} {:trigger b[j]} {:trigger a[j]} :: 0 <= j < i ==> a[j] * b[j] == c[j]
    decreases a.Length - i
  {
    c[i] := a[i];
    i := i + 1;
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  a.Length == b.Length
  //   POST: c.Length == a.Length
  //   POST: forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i]
  {
    var a := new int[0] [];
    var b := new int[0] [];
    expect a.Length == b.Length; // PRE-CHECK
    var c := arrayProduct(a, b);
    expect c.Length == a.Length;
    expect forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i];
  }

}

method Failing()
{
  // Test case for combination {1}/Ba=2,b=2:
  //   PRE:  a.Length == b.Length
  //   POST: c.Length == a.Length
  //   POST: forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i]
  {
    var a := new int[2] [4, 3];
    var b := new int[2] [6, 5];
    // expect a.Length == b.Length; // PRE-CHECK
    var c := arrayProduct(a, b);
    // expect c.Length == a.Length;
    // expect forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i];
  }

  // Test case for combination {1}/Ba=1,b=1:
  //   PRE:  a.Length == b.Length
  //   POST: c.Length == a.Length
  //   POST: forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i]
  {
    var a := new int[1] [2];
    var b := new int[1] [3];
    // expect a.Length == b.Length; // PRE-CHECK
    var c := arrayProduct(a, b);
    // expect c.Length == a.Length;
    // expect forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i];
  }

  // Test case for combination {1}/Ba=3,b=3:
  //   PRE:  a.Length == b.Length
  //   POST: c.Length == a.Length
  //   POST: forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i]
  {
    var a := new int[3] [5, 4, 6];
    var b := new int[3] [8, 7, 9];
    // expect a.Length == b.Length; // PRE-CHECK
    var c := arrayProduct(a, b);
    // expect c.Length == a.Length;
    // expect forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i];
  }

  // Test case for combination {1}/R5:
  //   PRE:  a.Length == b.Length
  //   POST: c.Length == a.Length
  //   POST: forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i]
  {
    var a := new int[4] [7, 8, 9, 10];
    var b := new int[4] [21, 22, 23, 24];
    // expect a.Length == b.Length; // PRE-CHECK
    var c := arrayProduct(a, b);
    // expect c.Length == a.Length;
    // expect forall i: int {:trigger c[i]} {:trigger b[i]} {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] * b[i] == c[i];
  }

}

method Main()
{
  Passing();
  Failing();
}
