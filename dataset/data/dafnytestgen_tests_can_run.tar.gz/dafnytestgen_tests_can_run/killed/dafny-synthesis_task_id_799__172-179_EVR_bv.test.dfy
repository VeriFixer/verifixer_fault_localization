// dafny-synthesis_task_id_799.dfy

method RotateLeftBits(n: bv32, d: int) returns (result: bv32)
  requires 0 <= d < 32
  ensures result == (n << d as bv6) | (n >> (32 - d) as bv6)
  decreases n, d
{
  result := (n << d as bv6) | (n >> 0 as bv6);
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  0 <= d < 32
  //   POST: result == (n << d as bv6) | (n >> (32 - d) as bv6)
  {
    var n := 0;
    var d := 0;
    expect 0 <= d < 32; // PRE-CHECK
    var result := RotateLeftBits(n, d);
    expect result == 0;
  }

  // Test case for combination {1}/Bd=0:
  //   PRE:  0 <= d < 32
  //   POST: result == (n << d as bv6) | (n >> (32 - d) as bv6)
  {
    var n := 1;
    var d := 0;
    expect 0 <= d < 32; // PRE-CHECK
    var result := RotateLeftBits(n, d);
    expect result == 1;
  }

  // Test case for combination {1}/Bd=1:
  //   PRE:  0 <= d < 32
  //   POST: result == (n << d as bv6) | (n >> (32 - d) as bv6)
  {
    var n := 0;
    var d := 1;
    expect 0 <= d < 32; // PRE-CHECK
    var result := RotateLeftBits(n, d);
    expect result == 0;
  }

  // Test case for combination {1}/Bd=30:
  //   PRE:  0 <= d < 32
  //   POST: result == (n << d as bv6) | (n >> (32 - d) as bv6)
  {
    var n := 0;
    var d := 30;
    expect 0 <= d < 32; // PRE-CHECK
    var result := RotateLeftBits(n, d);
    expect result == 0;
  }

  // Test case for combination {1}/Bd=31:
  //   PRE:  0 <= d < 32
  //   POST: result == (n << d as bv6) | (n >> (32 - d) as bv6)
  {
    var n := 0;
    var d := 31;
    expect 0 <= d < 32; // PRE-CHECK
    var result := RotateLeftBits(n, d);
    expect result == 0;
  }

}

method Failing()
{
  // (no failing tests)
}

method Main()
{
  Passing();
  Failing();
}
