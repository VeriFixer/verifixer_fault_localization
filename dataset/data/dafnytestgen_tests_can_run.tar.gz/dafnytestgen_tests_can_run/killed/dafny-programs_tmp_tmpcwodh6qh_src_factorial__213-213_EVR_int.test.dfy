// dafny-programs_tmp_tmpcwodh6qh_src_factorial.dfy

function fact(n: nat): nat
  ensures fact(n) >= 1
  decreases n
{
  if n == 0 then
    1
  else
    n * fact(n - 1)
}

method factorial(n: nat) returns (res: nat)
  ensures res == fact(n)
  decreases n
{
  var i := 1;
  res := 1;
  while 0 < n + 1
    invariant 0 < i <= n + 1
    invariant res == fact(i - 1)
    decreases n + 1 - 0
  {
    res := i * res;
    i := i + 1;
  }
}


method Passing()
{
  // (no passing tests)
}

method Failing()
{
  // Test case for combination {1}:
  //   POST: res == fact(n)
  {
    var n := 0;
    var check_res := fact(n);
    var res := factorial(n);
    // expect res == check_res;
  }

  // Test case for combination {1}/Bn=1:
  //   POST: res == fact(n)
  {
    var n := 1;
    var check_res := fact(n);
    var res := factorial(n);
    // expect res == check_res;
  }

  // Test case for combination {1}/R3:
  //   POST: res == fact(n)
  {
    var n := 2;
    var check_res := fact(n);
    var res := factorial(n);
    // expect res == check_res;
  }

  // Test case for combination {1}/R4:
  //   POST: res == fact(n)
  {
    var n := 3;
    var check_res := fact(n);
    var res := factorial(n);
    // expect res == check_res;
  }

  // Test case for combination {1}/R5:
  //   POST: res == fact(n)
  {
    var n := 4;
    var check_res := fact(n);
    var res := factorial(n);
    // expect res == check_res;
  }

}

method Main()
{
  Passing();
  Failing();
}
