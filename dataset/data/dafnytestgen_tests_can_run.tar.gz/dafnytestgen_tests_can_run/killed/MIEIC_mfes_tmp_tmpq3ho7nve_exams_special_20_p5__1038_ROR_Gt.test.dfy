// MIEIC_mfes_tmp_tmpq3ho7nve_exams_special_20_p5.dfy

predicate sorted(a: array<T>, n: nat)
  requires n <= a.Length
  reads a
  decreases {a}, a, n
{
  forall i: int, j: int {:trigger a[j], a[i]} :: 
    0 <= i < j < n ==>
      a[i] <= a[j]
}

method binarySearch(a: array<T>, x: T) returns (index: int)
  requires sorted(a, a.Length)
  ensures sorted(a, a.Length)
  ensures 0 <= index <= a.Length
  ensures index > 0 ==> a[index - 1] <= x
  ensures index < a.Length ==> a[index] >= x
  decreases a, x
{
  var low, high := 0, a.Length;
  while low < high
    invariant 0 <= low <= high <= a.Length
    invariant low > 0 ==> a[low - 1] <= x
    invariant high < a.Length ==> a[high] >= x
    decreases high - low
  {
    var mid := low + (high - low) / 2;
    if {
      case a[mid] > x =>
        low := mid + 1;
      case a[mid] > x =>
        high := mid;
      case a[mid] == x =>
        return mid;
    }
  }
  return low;
}

method testBinarySearch()
{
  var a := new int[2] [1, 3];
  var id0 := binarySearch(a, 0);
  assert id0 == 0;
  var id1 := binarySearch(a, 1);
  assert id1 in {0, 1};
  var id2 := binarySearch(a, 2);
  assert id2 == 1;
  var id3 := binarySearch(a, 3);
  assert id3 in {1, 2};
  var id4 := binarySearch(a, 4);
  assert id4 == 2;
}

type T = int


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: !(index < a.Length)
  {
    var a := new T[0] [];
    var x := 0;
    expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    expect index == 0;
    expect sorted(a, a.Length);
  }

  // Test case for combination {2}:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: a[index] >= x
  {
    var a := new T[1] [2];
    var x := 2;
    expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    expect index == 0;
    expect sorted(a, a.Length);
  }

  // Test case for combination {1}/Ba=0,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: !(index < a.Length)
  {
    var a := new T[0] [];
    var x := 1;
    expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    expect index == 0;
    expect sorted(a, a.Length);
  }

  // Test case for combination {2}/Ba=1,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: a[index] >= x
  {
    var a := new T[1] [1];
    var x := 1;
    expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    expect index == 0;
    expect sorted(a, a.Length);
  }

  // Test case for combination {1}/R3:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: !(index < a.Length)
  {
    var a := new T[0] [];
    var x := 2;
    expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    expect index == 0;
    expect sorted(a, a.Length);
  }

  // Test case for combination {1}/R4:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: !(index < a.Length)
  {
    var a := new T[0] [];
    var x := 3;
    expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    expect index == 0;
    expect sorted(a, a.Length);
  }

  // Test case for combination {1}/R5:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: !(index < a.Length)
  {
    var a := new T[0] [];
    var x := 4;
    expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    expect index == 0;
    expect sorted(a, a.Length);
  }

}

method Failing()
{
  // Test case for combination {3}:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: !(index < a.Length)
  {
    var a := new T[1] [-38];
    var x := 0;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 1;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {4}:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: a[index] >= x
  {
    var a := new T[2] [-38, 7719];
    var x := 0;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 1;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {2}/Ba=3,x=0:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: a[index] >= x
  {
    var a := new T[3] [609, 610, 611];
    var x := 0;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 0;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {2}/Ba=2,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: a[index] >= x
  {
    var a := new T[2] [39, 40];
    var x := 1;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 0;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {2}/Ba=3,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: a[index] >= x
  {
    var a := new T[3] [39, 40, 41];
    var x := 1;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 0;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {2}/Ba=1,x=0:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: a[index] >= x
  {
    var a := new T[1] [38];
    var x := 0;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 0;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {2}/Ba=2,x=0:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: !(index > 0)
  //   POST: a[index] >= x
  {
    var a := new T[2] [38, 39];
    var x := 0;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 0;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {3}/Ba=2,x=0:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: !(index < a.Length)
  {
    var a := new T[2] [-39, -38];
    var x := 0;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 2;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {3}/Ba=1,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: !(index < a.Length)
  {
    var a := new T[1] [-37];
    var x := 1;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 1;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {3}/Ba=3,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: !(index < a.Length)
  {
    var a := new T[3] [-39, -38, -37];
    var x := 1;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 3;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {3}/Ba=3,x=0:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: !(index < a.Length)
  {
    var a := new T[3] [-40, -39, -38];
    var x := 0;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 3;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {3}/Ba=2,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: !(index < a.Length)
  {
    var a := new T[2] [-38, -37];
    var x := 1;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 2;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {4}/Ba=2,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: a[index] >= x
  {
    var a := new T[2] [-7719, 1237];
    var x := 1;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 1;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {4}/Ba=3,x=0:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: a[index] >= x
  {
    var a := new T[3] [-38, 7719, 7720];
    var x := 0;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 1;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {4}/Ba=3,x=1:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: a[index] >= x
  {
    var a := new T[3] [-37, 7720, 7721];
    var x := 1;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 1;
    // expect sorted(a, a.Length);
  }

  // Test case for combination {4}/R5:
  //   PRE:  sorted(a, a.Length)
  //   POST: sorted(a, a.Length)
  //   POST: 0 <= index <= a.Length
  //   POST: a[index - 1] <= x
  //   POST: a[index] >= x
  {
    var a := new T[2] [-1, 37];
    var x := -1;
    // expect sorted(a, a.Length); // PRE-CHECK
    var index := binarySearch(a, x);
    // expect index == 1;
    // expect sorted(a, a.Length);
  }

}

method Main()
{
  Passing();
  Failing();
}
