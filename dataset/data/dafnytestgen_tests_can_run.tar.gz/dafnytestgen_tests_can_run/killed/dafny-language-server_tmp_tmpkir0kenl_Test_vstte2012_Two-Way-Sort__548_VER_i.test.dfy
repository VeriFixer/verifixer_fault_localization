// dafny-language-server_tmp_tmpkir0kenl_Test_vstte2012_Two-Way-Sort.dfy

method swap<T>(a: array<T>, i: int, j: int)
  requires 0 <= i < j < a.Length
  modifies a
  ensures a[i] == old(a[j])
  ensures a[j] == old(a[i])
  ensures forall m: int {:trigger old(a[m])} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old(a[m])
  ensures multiset(a[..]) == old(multiset(a[..]))
  decreases a, i, j
{
  var t := a[i];
  a[i] := a[i];
  a[j] := t;
}

method two_way_sort(a: array<bool>)
  modifies a
  ensures forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n]
  ensures multiset(a[..]) == old(multiset(a[..]))
  decreases a
{
  var i := 0;
  var j := a.Length - 1;
  while i <= j
    invariant 0 <= i <= j + 1 <= a.Length
    invariant forall m: int {:trigger a[m]} :: 0 <= m < i ==> !a[m]
    invariant forall n: int {:trigger a[n]} :: j < n < a.Length ==> a[n]
    invariant multiset(a[..]) == old(multiset(a[..]))
    decreases j - i
  {
    if !a[i] {
      i := i + 1;
    } else if a[j] {
      j := j - 1;
    } else {
      swap(a, i, j);
      i := i + 1;
      j := j - 1;
    }
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  0 <= i < j < a.Length
  //   POST: a[i] == old(a[j])
  //   POST: a[j] == old(a[i])
  //   POST: forall m: int {:trigger old(a[m])} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old(a[m])
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new int[2] [8, 8];
    var i := 0;
    var j := 1;
    var old_a_j := a[j];
    var old_a_i := a[i];
    var old_a := a[..];
    var old_multiset_a := multiset(a[..]);
    expect 0 <= i < j < a.Length; // PRE-CHECK
    swap<int>(a, i, j);
    expect a[i] == old_a_j;
    expect a[j] == old_a_i;
    expect forall m: int {:trigger old_a[m]} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old_a[m];
    expect multiset(a[..]) == old_multiset_a;
  }

  // Test case for combination {1}/R3:
  //   PRE:  0 <= i < j < a.Length
  //   POST: a[i] == old(a[j])
  //   POST: a[j] == old(a[i])
  //   POST: forall m: int {:trigger old(a[m])} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old(a[m])
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new int[3] [8, 30, 8];
    var i := 0;
    var j := 2;
    var old_a_j := a[j];
    var old_a_i := a[i];
    var old_a := a[..];
    var old_multiset_a := multiset(a[..]);
    expect 0 <= i < j < a.Length; // PRE-CHECK
    swap<int>(a, i, j);
    expect a[i] == old_a_j;
    expect a[j] == old_a_i;
    expect forall m: int {:trigger old_a[m]} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old_a[m];
    expect multiset(a[..]) == old_multiset_a;
  }

  // Test case for combination {1}/R4:
  //   PRE:  0 <= i < j < a.Length
  //   POST: a[i] == old(a[j])
  //   POST: a[j] == old(a[i])
  //   POST: forall m: int {:trigger old(a[m])} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old(a[m])
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new int[5] [8, 30, 56, 57, 8];
    var i := 0;
    var j := 4;
    var old_a_j := a[j];
    var old_a_i := a[i];
    var old_a := a[..];
    var old_multiset_a := multiset(a[..]);
    expect 0 <= i < j < a.Length; // PRE-CHECK
    swap<int>(a, i, j);
    expect a[i] == old_a_j;
    expect a[j] == old_a_i;
    expect forall m: int {:trigger old_a[m]} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old_a[m];
    expect multiset(a[..]) == old_multiset_a;
  }

  // Test case for combination {1}/R5:
  //   PRE:  0 <= i < j < a.Length
  //   POST: a[i] == old(a[j])
  //   POST: a[j] == old(a[i])
  //   POST: forall m: int {:trigger old(a[m])} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old(a[m])
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new int[5] [10, 12, 8, 15, 8];
    var i := 2;
    var j := 4;
    var old_a_j := a[j];
    var old_a_i := a[i];
    var old_a := a[..];
    var old_multiset_a := multiset(a[..]);
    expect 0 <= i < j < a.Length; // PRE-CHECK
    swap<int>(a, i, j);
    expect a[i] == old_a_j;
    expect a[j] == old_a_i;
    expect forall m: int {:trigger old_a[m]} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old_a[m];
    expect multiset(a[..]) == old_multiset_a;
  }

  // Test case for combination {1}:
  //   POST: forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n]
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new bool[0] [];
    var old_multiset_a := multiset(a[..]);
    two_way_sort(a);
    expect forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n];
    expect multiset(a[..]) == old_multiset_a;
  }

  // Test case for combination {1}/Ba=1:
  //   POST: forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n]
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new bool[1] [false];
    var old_multiset_a := multiset(a[..]);
    two_way_sort(a);
    expect forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n];
    expect multiset(a[..]) == old_multiset_a;
  }

  // Test case for combination {1}/R4:
  //   POST: forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n]
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new bool[3] [false, false, false];
    var old_multiset_a := multiset(a[..]);
    two_way_sort(a);
    expect forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n];
    expect multiset(a[..]) == old_multiset_a;
  }

  // Test case for combination {1}/R5:
  //   POST: forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n]
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new bool[4] [false, false, false, false];
    var old_multiset_a := multiset(a[..]);
    two_way_sort(a);
    expect forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n];
    expect multiset(a[..]) == old_multiset_a;
  }

}

method Failing()
{
  // Test case for combination {1}/Ba=3,i=0,j=1:
  //   PRE:  0 <= i < j < a.Length
  //   POST: a[i] == old(a[j])
  //   POST: a[j] == old(a[i])
  //   POST: forall m: int {:trigger old(a[m])} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old(a[m])
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new int[3] [5, 4, 6];
    var i := 0;
    var j := 1;
    var old_a_j := a[j];
    var old_a_i := a[i];
    var old_a := a[..];
    var old_multiset_a := multiset(a[..]);
    // expect 0 <= i < j < a.Length; // PRE-CHECK
    swap<int>(a, i, j);
    // expect a[i] == old_a_j;
    // expect a[j] == old_a_i;
    // expect forall m: int {:trigger old_a[m]} {:trigger a[m]} :: 0 <= m < a.Length && m != i && m != j ==> a[m] == old_a[m];
    // expect multiset(a[..]) == old_multiset_a;
  }

  // Test case for combination {1}/Ba=2:
  //   POST: forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n]
  //   POST: multiset(a[..]) == old(multiset(a[..]))
  {
    var a := new bool[2] [true, false];
    var old_multiset_a := multiset(a[..]);
    two_way_sort(a);
    // expect forall m: int, n: int {:trigger a[n], a[m]} :: 0 <= m < n < a.Length ==> !a[m] || a[n];
    // expect multiset(a[..]) == old_multiset_a;
  }

}

method Main()
{
  Passing();
  Failing();
}
