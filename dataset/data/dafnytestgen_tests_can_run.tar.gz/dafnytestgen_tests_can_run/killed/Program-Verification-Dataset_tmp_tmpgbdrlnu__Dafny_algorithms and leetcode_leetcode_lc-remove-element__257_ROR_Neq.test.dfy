// Program-Verification-Dataset_tmp_tmpgbdrlnu__Dafny_algorithms and leetcode_leetcode_lc-remove-element.dfy

method removeElement(nums: array<int>, val: int) returns (i: int)
  modifies nums
  ensures forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  decreases nums, val
{
  i := 0;
  var end := nums.Length - 1;
  while i != end
    invariant 0 <= i <= nums.Length
    invariant end < nums.Length
    invariant forall k: int {:trigger nums[k]} :: 0 <= k < i ==> nums[k] != val
    decreases if i <= end then end - i else i - end
  {
    if nums[i] == val {
      if nums[end] == val {
        end := end - 1;
      } else {
        nums[i], nums[end] := nums[end], nums[i];
        i := i + 1;
        end := end - 1;
      }
    } else {
      i := i + 1;
    }
  }
}

method OriginalMain()
{
  var elems := new int[5] [1, 2, 3, 4, 5];
  var res := removeElement(elems, 5);
  print res, "\n", elems;
}


method Passing()
{
  // (no passing tests)
}

method Failing()
{
  // Test case for combination {1}:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[0] [];
    var val := 9;
    var i := removeElement(nums, val);
    // expect i == 0;
  }

  // Test case for combination {1}/Bnums=0,val=0:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[0] [];
    var val := 0;
    var i := removeElement(nums, val);
    // expect i == 0;
  }

  // Test case for combination {1}/Bnums=0,val=1:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[0] [];
    var val := 1;
    var i := removeElement(nums, val);
    // expect i == 0;
  }

  // Test case for combination {1}/Bnums=1,val=0:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[1] [16];
    var val := 0;
    var i := removeElement(nums, val);
    // expect i == 1;
  }

  // Test case for combination {1}/Bnums=1,val=1:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[1] [16];
    var val := 1;
    var i := removeElement(nums, val);
    // expect i == 1;
  }

  // Test case for combination {1}/Bnums=2,val=0:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[2] [15, 14];
    var val := 0;
    var i := removeElement(nums, val);
    // expect i == 2;
  }

  // Test case for combination {1}/Bnums=2,val=1:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[2] [15, 14];
    var val := 1;
    var i := removeElement(nums, val);
    // expect i == 2;
  }

  // Test case for combination {1}/Bnums=3,val=0:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[3] [14, 13, 15];
    var val := 0;
    var i := removeElement(nums, val);
    // expect i == 3;
  }

  // Test case for combination {1}/Bnums=3,val=1:
  //   POST: forall k: int {:trigger nums[k]} :: 0 < k < i < nums.Length ==> nums[k] != val
  {
    var nums := new int[3] [14, 13, 15];
    var val := 1;
    var i := removeElement(nums, val);
    // expect i == 3;
  }

}

method Main()
{
  Passing();
  Failing();
}
