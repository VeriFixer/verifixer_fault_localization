// Clover_cal_ans.dfy

method CalDiv() returns (x: int, y: int)
  ensures x == 191 / 7
  ensures y == 191 % 7
{
  x, y := 0, 191;
  while 7 <= y
    invariant 0 <= y && 7 * x + y == 191
    decreases y - 7
  {
    x := x + 1;
    y := 191;
  }
}


method Passing()
{
  // (no passing tests)
}

method Failing()
{
  // Test case for combination {1}:
  //   POST: x == 191 / 7
  //   POST: y == 191 % 7
  {
    var x, y := CalDiv();
    // expect x == 27;
    // expect y == 2;
  }

}

method Main()
{
  Passing();
  Failing();
}
