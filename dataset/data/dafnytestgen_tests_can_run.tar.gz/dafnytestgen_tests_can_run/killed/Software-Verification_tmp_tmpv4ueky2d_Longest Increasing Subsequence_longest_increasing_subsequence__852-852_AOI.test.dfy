// Software-Verification_tmp_tmpv4ueky2d_Longest Increasing Subsequence_longest_increasing_subsequence.dfy

method longest_increasing_subsequence(nums: array<int>) returns (max: int)
  requires 1 <= nums.Length <= 2500
  requires forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000)
  ensures max >= 1
  decreases nums
{
  var length := nums.Length;
  if length == 1 {
    return 1;
  }
  max := 1;
  var dp := new int[length] ((_ /* _v0 */: nat) => 1);
  var i := 1;
  while i < length
    invariant 1 <= i <= length
    invariant max >= 1
    decreases length - i
    modifies dp
  {
    var j := 0;
    while j < i
      invariant 0 <= j <= i
      decreases i - j
    {
      if nums[j] < nums[i] {
        dp[i] := find_max(dp[i], dp[j] + 1);
      }
      j := j + 1;
    }
    max := find_max(max, dp[-i]);
    i := i + 1;
  }
}

function find_max(x: int, y: int): int
  decreases x, y
{
  if x > y then
    x
  else
    y
}


method GeneratedTests_longest_increasing_subsequence()
{
  // Test case for combination {1}:
  //   PRE:  1 <= nums.Length <= 2500
  //   PRE:  forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000)
  //   POST: max >= 1
  {
    var nums := new int[1] [-9962];
    expect 1 <= nums.Length <= 2500; // PRE-CHECK
    expect forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000); // PRE-CHECK
    var max := longest_increasing_subsequence(nums);
    expect max == 1;
  }

  // Test case for combination {1}/Bnums=2:
  //   PRE:  1 <= nums.Length <= 2500
  //   PRE:  forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000)
  //   POST: max >= 1
  {
    var nums := new int[2] [-2281, -2280];
    expect 1 <= nums.Length <= 2500; // PRE-CHECK
    expect forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000); // PRE-CHECK
    var max := longest_increasing_subsequence(nums);
    expect max == 1;
  }

  // Test case for combination {1}/Bnums=3:
  //   PRE:  1 <= nums.Length <= 2500
  //   PRE:  forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000)
  //   POST: max >= 1
  {
    var nums := new int[3] [-2281, -2280, -2279];
    expect 1 <= nums.Length <= 2500; // PRE-CHECK
    expect forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000); // PRE-CHECK
    var max := longest_increasing_subsequence(nums);
    expect max == 1;
  }

  // Test case for combination {1}/R4:
  //   PRE:  1 <= nums.Length <= 2500
  //   PRE:  forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000)
  //   POST: max >= 1
  {
    var nums := new int[4] [-9962, -2281, -8763, -7563];
    expect 1 <= nums.Length <= 2500; // PRE-CHECK
    expect forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000); // PRE-CHECK
    var max := longest_increasing_subsequence(nums);
    expect max == 1;
  }

  // Test case for combination {1}/R5:
  //   PRE:  1 <= nums.Length <= 2500
  //   PRE:  forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000)
  //   POST: max >= 1
  {
    var nums := new int[5] [-9962, -2281, -8763, -7563, -1145];
    expect 1 <= nums.Length <= 2500; // PRE-CHECK
    expect forall i: int {:trigger nums[i]} :: (0 <= i < nums.Length ==> -10000 <= nums[i]) && (0 <= i < nums.Length ==> nums[i] <= 10000); // PRE-CHECK
    var max := longest_increasing_subsequence(nums);
    expect max == 1;
  }

}

method Main()
{
  GeneratedTests_longest_increasing_subsequence();
  print "GeneratedTests_longest_increasing_subsequence: all tests passed!\n";
}
