// dafny-exercise_tmp_tmpouftptir_prac1_ex2.dfy

method Deli(a: array<char>, i: nat)
  requires a.Length > 0
  requires 0 <= i < a.Length
  modifies a
  ensures forall j: int {:trigger old(a[j])} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old(a[j])
  ensures forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old(a[j + 1])
  ensures a[a.Length - 1] == '.'
  decreases a, i
{
  var c := i;
  while c < a.Length - 1
    invariant i <= c <= a.Length - 1
    invariant forall j: int {:trigger a[j]} :: i <= j < c ==> a[j] == old(a[j + 1])
    invariant forall j: int {:trigger old(a[j])} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old(a[j])
    invariant forall j: int {:trigger old(a[j])} {:trigger a[j]} :: c <= j < a.Length ==> a[j] == old(a[j])
    decreases a.Length - 1 - c
  {
    a[c] := a[c + 1];
    c := c + 1;
  }
  a[c] := '.';
}

method DeliChecker()
{
  var z := new char[] ['b', 'r', 'o', 'o', 'm'];
  Deli(z, 1);
  assert z[..] == "boom.";
  Deli(z, 3);
  assert z[..] == "boo..";
  Deli(z, 4);
  assert z[..] == "boo..";
  Deli(z, 3);
  assert z[..] == "boo..";
  Deli(z, 0);
  Deli(z, 0);
  Deli(z, 0);
  assert z[..] == ".....";
  z := new char[] ['x'];
  Deli(z, 0);
  assert z[..] == ".";
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  a.Length > 0
  //   PRE:  0 <= i < a.Length
  //   POST: forall j: int {:trigger old(a[j])} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old(a[j])
  //   POST: forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old(a[j + 1])
  //   POST: a[a.Length - 1] == '.'
  {
    var a := new char[1] [' '];
    var i := 0;
    var old_a := a[..];
    expect a.Length > 0; // PRE-CHECK
    expect 0 <= i < a.Length; // PRE-CHECK
    Deli(a, i);
    expect forall j: int {:trigger old_a[j]} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old_a[j];
    expect forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old_a[j + 1];
    expect a[a.Length - 1] == '.';
  }

  // Test case for combination {1}/Ba=2,i=0:
  //   PRE:  a.Length > 0
  //   PRE:  0 <= i < a.Length
  //   POST: forall j: int {:trigger old(a[j])} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old(a[j])
  //   POST: forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old(a[j + 1])
  //   POST: a[a.Length - 1] == '.'
  {
    var a := new char[2] [' ', '!'];
    var i := 0;
    var old_a := a[..];
    expect a.Length > 0; // PRE-CHECK
    expect 0 <= i < a.Length; // PRE-CHECK
    Deli(a, i);
    expect forall j: int {:trigger old_a[j]} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old_a[j];
    expect forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old_a[j + 1];
    expect a[a.Length - 1] == '.';
  }

  // Test case for combination {1}/Ba=2,i=1:
  //   PRE:  a.Length > 0
  //   PRE:  0 <= i < a.Length
  //   POST: forall j: int {:trigger old(a[j])} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old(a[j])
  //   POST: forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old(a[j + 1])
  //   POST: a[a.Length - 1] == '.'
  {
    var a := new char[2] [' ', '!'];
    var i := 1;
    var old_a := a[..];
    expect a.Length > 0; // PRE-CHECK
    expect 0 <= i < a.Length; // PRE-CHECK
    Deli(a, i);
    expect forall j: int {:trigger old_a[j]} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old_a[j];
    expect forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old_a[j + 1];
    expect a[a.Length - 1] == '.';
  }

  // Test case for combination {1}/Ba=3,i=0:
  //   PRE:  a.Length > 0
  //   PRE:  0 <= i < a.Length
  //   POST: forall j: int {:trigger old(a[j])} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old(a[j])
  //   POST: forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old(a[j + 1])
  //   POST: a[a.Length - 1] == '.'
  {
    var a := new char[3] [' ', '"', '!'];
    var i := 0;
    var old_a := a[..];
    expect a.Length > 0; // PRE-CHECK
    expect 0 <= i < a.Length; // PRE-CHECK
    Deli(a, i);
    expect forall j: int {:trigger old_a[j]} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old_a[j];
    expect forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old_a[j + 1];
    expect a[a.Length - 1] == '.';
  }

  // Test case for combination {1}/Ba=3,i=1:
  //   PRE:  a.Length > 0
  //   PRE:  0 <= i < a.Length
  //   POST: forall j: int {:trigger old(a[j])} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old(a[j])
  //   POST: forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old(a[j + 1])
  //   POST: a[a.Length - 1] == '.'
  {
    var a := new char[3] [' ', '!', '"'];
    var i := 1;
    var old_a := a[..];
    expect a.Length > 0; // PRE-CHECK
    expect 0 <= i < a.Length; // PRE-CHECK
    Deli(a, i);
    expect forall j: int {:trigger old_a[j]} {:trigger a[j]} :: 0 <= j < i ==> a[j] == old_a[j];
    expect forall j: int {:trigger a[j]} :: i <= j < a.Length - 1 ==> a[j] == old_a[j + 1];
    expect a[a.Length - 1] == '.';
  }

}

method Failing()
{
  // (no failing tests)
}

method Main()
{
  Passing();
  Failing();
}
