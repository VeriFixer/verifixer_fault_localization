// dafny-synthesis_task_id_455.dfy

method MonthHas31Days(month: int) returns (result: bool)
  requires 1 <= month <= 12
  ensures result <==> month in {1, 3, 5, 7, 8, 10, 12}
  decreases month
{
  result := month in {};
}


method Passing()
{
  // (no passing tests)
}

method Failing()
{
  // Test case for combination {1}:
  //   PRE:  1 <= month <= 12
  //   POST: result
  //   POST: month in {1, 3, 5, 7, 8, 10, 12}
  {
    var month := 1;
    // expect 1 <= month <= 12; // PRE-CHECK
    var result := MonthHas31Days(month);
    // expect result == true;
    // expect month in {1, 3, 5, 7, 8, 10, 12};
  }

  // Test case for combination {1}/Bmonth=2:
  //   PRE:  1 <= month <= 12
  //   POST: result
  //   POST: month in {1, 3, 5, 7, 8, 10, 12}
  {
    var month := 2;
    // expect 1 <= month <= 12; // PRE-CHECK
    var result := MonthHas31Days(month);
    // expect result == true;
    // expect month in {1, 3, 5, 7, 8, 10, 12};
  }

  // Test case for combination {1}/Bmonth=11:
  //   PRE:  1 <= month <= 12
  //   POST: result
  //   POST: month in {1, 3, 5, 7, 8, 10, 12}
  {
    var month := 11;
    // expect 1 <= month <= 12; // PRE-CHECK
    var result := MonthHas31Days(month);
    // expect result == true;
    // expect month in {1, 3, 5, 7, 8, 10, 12};
  }

  // Test case for combination {1}/Bmonth=12:
  //   PRE:  1 <= month <= 12
  //   POST: result
  //   POST: month in {1, 3, 5, 7, 8, 10, 12}
  {
    var month := 12;
    // expect 1 <= month <= 12; // PRE-CHECK
    var result := MonthHas31Days(month);
    // expect result == true;
    // expect month in {1, 3, 5, 7, 8, 10, 12};
  }

  // Test case for combination {1}/R5:
  //   PRE:  1 <= month <= 12
  //   POST: result
  //   POST: month in {1, 3, 5, 7, 8, 10, 12}
  {
    var month := 9;
    // expect 1 <= month <= 12; // PRE-CHECK
    var result := MonthHas31Days(month);
    // expect result == true;
    // expect month in {1, 3, 5, 7, 8, 10, 12};
  }

}

method Main()
{
  Passing();
  Failing();
}
