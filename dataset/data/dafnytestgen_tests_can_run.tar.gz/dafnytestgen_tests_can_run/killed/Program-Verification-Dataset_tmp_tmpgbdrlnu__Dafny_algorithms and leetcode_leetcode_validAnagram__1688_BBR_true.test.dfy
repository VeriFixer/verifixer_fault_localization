// Program-Verification-Dataset_tmp_tmpgbdrlnu__Dafny_algorithms and leetcode_leetcode_validAnagram.dfy

method toMultiset(s: string) returns (mset: multiset<char>)
  ensures multiset(s) == mset
  decreases s
{
  mset := multiset{};
  for i: int := 0 to |s|
    invariant mset == multiset(s[0 .. i])
  {
    assert s == s[0 .. i] + [s[i]] + s[i + 1..];
    mset := mset + multiset{s[i]};
  }
  assert s == s[0 .. |s|];
  return mset;
}

method msetEqual(s: multiset<char>, t: multiset<char>) returns (equal: bool)
  ensures s == t <==> equal
  decreases s, t
{
  var sremoved: multiset<char> := multiset{};
  var scopy := s;
  while scopy != multiset{}
    invariant s - sremoved == scopy
    invariant sremoved !! scopy
    invariant sremoved <= s
    invariant forall x: char {:trigger t[x]} {:trigger s[x]} {:trigger sremoved[x]} :: (x in sremoved ==> x in s) && (x in sremoved ==> x in t) && (x in sremoved ==> t[x] == s[x])
    decreases scopy
  {
    var x :| x in scopy;
    if !(x in t && s[x] == t[x]) {
      return false;
    }
    var removed := multiset{};
    sremoved := sremoved + removed[x := s[x]];
    scopy := scopy - removed[x := s[x]];
  }
  var tremoved: multiset<char> := multiset{};
  var tcopy := t;
  while tcopy != multiset{}
    invariant t - tremoved == tcopy
    invariant tremoved !! tcopy
    invariant tremoved <= t
    invariant forall x: char {:trigger t[x]} {:trigger s[x]} {:trigger tremoved[x]} :: (x in tremoved ==> x in s) && (x in tremoved ==> x in t) && (x in tremoved ==> t[x] == s[x])
    decreases tcopy
  {
    var x :| x in tcopy;
    if !true {
      return false;
    }
    var removed := multiset{};
    tremoved := tremoved + removed[x := s[x]];
    tcopy := tcopy - removed[x := s[x]];
  }
  return true;
}

method isAnagram(s: string, t: string) returns (equal: bool)
  ensures (multiset(s) == multiset(t)) == equal
  decreases s, t
{
  var smset := toMultiset(s);
  var tmset := toMultiset(t);
  equal := msetEqual(smset, tmset);
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: multiset(s) == mset
  {
    var s: seq<char> := [];
    var mset := toMultiset(s);
    expect mset == multiset{};
  }

  // Test case for combination {1}:
  //   POST: s == t
  //   POST: equal
  {
    var s: multiset<char> := multiset{'a', 'a', 'b', 'c', 'c', 'c', 'd', 'd', 'd', 'e', 'e', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'g', 'g'};
    var t: multiset<char> := multiset{'a', 'a', 'b', 'c', 'c', 'c', 'd', 'd', 'd', 'e', 'e', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'g', 'g'};
    var equal := msetEqual(s, t);
    expect equal == true;
    expect s == t;
  }

  // Test case for combination {2}:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'a', 'a', 'b', 'b', 'b', 'b', 'b', 'b', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'g', 'g', 'g', 'g', 'g', 'h', 'h'};
    var t: multiset<char> := multiset{'a', 'b', 'b', 'b', 'c', 'c', 'c', 'd', 'd', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'f', 'f', 'g', 'g', 'g', 'g', 'g', 'g', 'h', 'h', 'h', 'h', 'h', 'h', 'h', 'h'};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {1}/Bs=3,t=3:
  //   POST: s == t
  //   POST: equal
  {
    var s: multiset<char> := multiset{'b', 'b', 'c'};
    var t: multiset<char> := multiset{'b', 'b', 'c'};
    var equal := msetEqual(s, t);
    expect equal == true;
    expect s == t;
  }

  // Test case for combination {1}/Bs=2,t=2:
  //   POST: s == t
  //   POST: equal
  {
    var s: multiset<char> := multiset{'b', 'b'};
    var t: multiset<char> := multiset{'b', 'b'};
    var equal := msetEqual(s, t);
    expect equal == true;
    expect s == t;
  }

  // Test case for combination {1}/Bs=1,t=1:
  //   POST: s == t
  //   POST: equal
  {
    var s: multiset<char> := multiset{'c'};
    var t: multiset<char> := multiset{'c'};
    var equal := msetEqual(s, t);
    expect equal == true;
    expect s == t;
  }

  // Test case for combination {1}/Bs=0,t=0:
  //   POST: s == t
  //   POST: equal
  {
    var s: multiset<char> := multiset{};
    var t: multiset<char> := multiset{};
    var equal := msetEqual(s, t);
    expect equal == true;
    expect s == t;
  }

  // Test case for combination {2}/Bs=2,t=1:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'h', 'h'};
    var t: multiset<char> := multiset{'g'};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=3,t=3:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'b', 'h', 'h'};
    var t: multiset<char> := multiset{'b', 'g', 'h'};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=3,t=2:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'b', 'h', 'h'};
    var t: multiset<char> := multiset{'b', 'g'};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=3,t=1:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'b', 'h', 'h'};
    var t: multiset<char> := multiset{'g'};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=3,t=0:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'g', 'h', 'h'};
    var t: multiset<char> := multiset{};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=2,t=3:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'h', 'h'};
    var t: multiset<char> := multiset{'b', 'c', 'g'};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=2,t=2:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'h', 'h'};
    var t: multiset<char> := multiset{'g', 'h'};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=2,t=0:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'g', 'h'};
    var t: multiset<char> := multiset{};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=1,t=1:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'b'};
    var t: multiset<char> := multiset{'g'};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {2}/Bs=1,t=0:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'g'};
    var t: multiset<char> := multiset{};
    var equal := msetEqual(s, t);
    expect equal == false;
    expect !(s == t);
  }

  // Test case for combination {1}:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [];
    var t: seq<char> := [];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=3,t=1:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := ['!', ' ', '"'];
    var t: seq<char> := ['F'];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=3,t=0:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' ', '"', '!'];
    var t: seq<char> := [];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=2,t=2:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' ', '!'];
    var t: seq<char> := ['+', ','];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=2,t=1:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' ', '!'];
    var t: seq<char> := ['F'];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=2,t=0:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' ', '!'];
    var t: seq<char> := [];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=3,t=2:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' ', '!', '"'];
    var t: seq<char> := ['+', ','];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=1,t=3:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := ['F'];
    var t: seq<char> := ['!', ' ', '"'];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=1,t=1:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' '];
    var t: seq<char> := ['F'];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=1,t=0:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' '];
    var t: seq<char> := [];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=1,t=2:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := ['F'];
    var t: seq<char> := [' ', '!'];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=3,t=3:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' ', '!', '"'];
    var t: seq<char> := [' ', '!', '\U{005C}'];
    var equal := isAnagram(s, t);
    expect (multiset(s) == multiset(t)) == equal;
  }

}

method Failing()
{
  // Test case for combination {1}/Bs=1:
  //   POST: multiset(s) == mset
  {
    var s: seq<char> := [' '];
    var mset := toMultiset(s);
    // expect mset == multiset{};
  }

  // Test case for combination {1}/Bs=2:
  //   POST: multiset(s) == mset
  {
    var s: seq<char> := [' ', '!'];
    var mset := toMultiset(s);
    // expect mset == multiset{};
  }

  // Test case for combination {1}/Bs=3:
  //   POST: multiset(s) == mset
  {
    var s: seq<char> := [' ', '!', '"'];
    var mset := toMultiset(s);
    // expect mset == multiset{};
  }

  // Test case for combination {1}/R5:
  //   POST: multiset(s) == mset
  {
    var s: seq<char> := [' ', '6', 'p', 'U'];
    var mset := toMultiset(s);
    // expect mset == multiset{};
  }

  // Test case for combination {2}/Bs=1,t=3:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'b'};
    var t: multiset<char> := multiset{'b', 'g', 'h'};
    var equal := msetEqual(s, t);
    // expect equal == false;
    // expect !(s == t);
  }

  // Test case for combination {2}/Bs=1,t=2:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{'b'};
    var t: multiset<char> := multiset{'b', 'g'};
    var equal := msetEqual(s, t);
    // expect equal == false;
    // expect !(s == t);
  }

  // Test case for combination {2}/Bs=0,t=3:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{};
    var t: multiset<char> := multiset{'g', 'h', 'h'};
    var equal := msetEqual(s, t);
    // expect equal == false;
    // expect !(s == t);
  }

  // Test case for combination {2}/Bs=0,t=2:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{};
    var t: multiset<char> := multiset{'b', 'g'};
    var equal := msetEqual(s, t);
    // expect equal == false;
    // expect !(s == t);
  }

  // Test case for combination {2}/Bs=0,t=1:
  //   POST: !(s == t)
  //   POST: !equal
  {
    var s: multiset<char> := multiset{};
    var t: multiset<char> := multiset{'g'};
    var equal := msetEqual(s, t);
    // expect equal == false;
    // expect !(s == t);
  }

  // Test case for combination {1}/Bs=2,t=3:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [' ', '!'];
    var t: seq<char> := [' ', '!', '"'];
    var equal := isAnagram(s, t);
    // expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=0,t=3:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [];
    var t: seq<char> := [' ', '"', '!'];
    var equal := isAnagram(s, t);
    // expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=0,t=2:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [];
    var t: seq<char> := [' ', '!'];
    var equal := isAnagram(s, t);
    // expect (multiset(s) == multiset(t)) == equal;
  }

  // Test case for combination {1}/Bs=0,t=1:
  //   POST: (multiset(s) == multiset(t)) == equal
  {
    var s: seq<char> := [];
    var t: seq<char> := [' '];
    var equal := isAnagram(s, t);
    // expect (multiset(s) == multiset(t)) == equal;
  }

}

method Main()
{
  Passing();
  Failing();
}
