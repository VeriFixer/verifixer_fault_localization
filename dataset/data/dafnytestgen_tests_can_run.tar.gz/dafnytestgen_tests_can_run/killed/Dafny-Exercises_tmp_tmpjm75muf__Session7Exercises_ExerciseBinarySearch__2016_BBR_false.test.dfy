// Dafny-Exercises_tmp_tmpjm75muf__Session7Exercises_ExerciseBinarySearch.dfy

predicate sorted(s: seq<int>)
  decreases s
{
  forall u: int, w: int {:trigger s[w], s[u]} :: 
    0 <= u < w < |s| ==>
      s[u] <= s[w]
}

method binarySearch(v: array<int>, elem: int) returns (p: int)
  requires sorted(v[0 .. v.Length])
  ensures -1 <= p < v.Length
  ensures (forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem) && forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  decreases v, elem
{
  var c, f := 0, v.Length - 1;
  while c <= f
    invariant 0 <= c <= v.Length && -1 <= f <= v.Length - 1 && c <= f + 1
    invariant (forall u: int {:trigger v[u]} :: 0 <= u < c ==> v[u] <= elem) && forall w: int {:trigger v[w]} :: f < w < v.Length ==> v[w] > elem
    decreases f - c
  {
    var m := (c + f) / 2;
    if v[m] <= elem {
      c := m + 1;
    } else {
      f := m - 1;
    }
  }
  p := c - 1;
}

method search(v: array<int>, elem: int) returns (b: bool)
  requires sorted(v[0 .. v.Length])
  ensures b == (elem in v[0 .. v.Length])
  decreases v, elem
{
  var p := binarySearch(v, elem);
  if p == -1 {
    b := false;
  } else {
    b := v[p] == elem;
  }
}

method {:tailrecursion false} binarySearchRec(v: array<int>, elem: int, c: int, f: int)
    returns (p: int)
  requires sorted(v[0 .. v.Length])
  requires 0 <= c <= f + 1 <= v.Length
  requires forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  requires forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  ensures -1 <= p < v.Length
  ensures (forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem) && forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  decreases f - c
{
  if c == f + 1 {
    p := c - 1;
  } else {
    var m := (c + f) / 2;
    if v[m] <= elem {
      p := binarySearchRec(v, elem, m + 1, f);
    } else {
      p := binarySearchRec(v, elem, c, m - 1);
    }
  }
}

method otherbSearch(v: array<int>, elem: int)
    returns (b: bool, p: int)
  requires sorted(v[0 .. v.Length])
  ensures 0 <= p <= v.Length
  ensures b == (elem in v[0 .. v.Length])
  ensures b ==> p < v.Length && v[p] == elem
  ensures !b ==> (forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem) && forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  decreases v, elem
{
  p := binarySearch(v, elem);
  if false {
    b := false;
    p := p + 1;
  } else {
    b := v[p] == elem;
    p := p + if b then 0 else 1;
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [2437];
    var elem := -1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var p := binarySearch(v, elem);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=0,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[0] [];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var p := binarySearch(v, elem);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=0,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[0] [];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var p := binarySearch(v, elem);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=1,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [1];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var p := binarySearch(v, elem);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=1,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [40];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var p := binarySearch(v, elem);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=2,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [7720, 7721];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var p := binarySearch(v, elem);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=2,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [7721, 7722];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var p := binarySearch(v, elem);
    expect p == -1;
  }

  // Test case for combination {1}:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: b == (elem in v[0 .. v.Length])
  {
    var v := new int[0] [];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b := search(v, elem);
    expect b == false;
  }

  // Test case for combination {1}/Bv=0,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: b == (elem in v[0 .. v.Length])
  {
    var v := new int[0] [];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b := search(v, elem);
    expect b == false;
  }

  // Test case for combination {1}/Bv=1,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: b == (elem in v[0 .. v.Length])
  {
    var v := new int[1] [2];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b := search(v, elem);
    expect b == false;
  }

  // Test case for combination {1}/Bv=1,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: b == (elem in v[0 .. v.Length])
  {
    var v := new int[1] [2];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b := search(v, elem);
    expect b == false;
  }

  // Test case for combination {1}:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[0] [];
    var elem := 0;
    var c := 0;
    var f := -1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=2,elem=0,c=0,f=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [7720, 7721];
    var elem := 0;
    var c := 0;
    var f := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=2,elem=0,c=1,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [-11797, 8366];
    var elem := 0;
    var c := 1;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == 0;
  }

  // Test case for combination {1}/Bv=2,elem=0,c==f,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [39, 40];
    var elem := 0;
    var c := 0;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=2,elem=1,c=0,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [11799, 11800];
    var elem := 1;
    var c := 0;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=2,elem=1,c=0,f=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [7721, 7722];
    var elem := 1;
    var c := 0;
    var f := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=2,elem=1,c=1,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [-11797, 2];
    var elem := 1;
    var c := 1;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == 0;
  }

  // Test case for combination {1}/Bv=3,elem=0,c=1,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[3] [-8855, 11798, 11799];
    var elem := 0;
    var c := 1;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == 0;
  }

  // Test case for combination {1}/Bv=3,elem=0,c=1,f=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[3] [-7074, 646, 647];
    var elem := 0;
    var c := 1;
    var f := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == 0;
  }

  // Test case for combination {1}/Bv=3,elem=1,c=1,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[3] [-8855, 11799, 11800];
    var elem := 1;
    var c := 1;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == 0;
  }

  // Test case for combination {1}/Bv=3,elem=1,c=1,f=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[3] [-11797, 8367, 8368];
    var elem := 1;
    var c := 1;
    var f := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == 0;
  }

  // Test case for combination {1}/Bv=1,elem=0,c=0,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [1];
    var elem := 0;
    var c := 0;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=1,elem=0,c=1,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [-8365];
    var elem := 0;
    var c := 1;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == 0;
  }

  // Test case for combination {1}/Bv=1,elem=1,c=0,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [40];
    var elem := 1;
    var c := 0;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == -1;
  }

  // Test case for combination {1}/Bv=1,elem=1,c=1,f=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   PRE:  0 <= c <= f + 1 <= v.Length
  //   PRE:  forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem
  //   PRE:  forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem
  //   POST: -1 <= p < v.Length
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u <= p ==> v[u] <= elem
  //   POST: forall w: int {:trigger v[w]} :: p < w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [-8365];
    var elem := 1;
    var c := 1;
    var f := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    expect 0 <= c <= f + 1 <= v.Length; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: 0 <= k < c ==> v[k] <= elem; // PRE-CHECK
    expect forall k: int {:trigger v[k]} :: f < k < v.Length ==> v[k] > elem; // PRE-CHECK
    var p := binarySearchRec(v, elem, c, f);
    expect p == 0;
  }

  // Test case for combination {3}:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: p < v.Length
  //   POST: v[p] == elem
  //   POST: b
  {
    var v := new int[1] [0];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    expect b == true;
    expect p == 0;
  }

  // Test case for combination {2}/Bv=1,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [-38];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    expect b == false;
    expect p == 1;
  }

  // Test case for combination {2}/Bv=1,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[1] [-1];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    expect b == false;
    expect p == 1;
  }

  // Test case for combination {3}/Bv=2,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: p < v.Length
  //   POST: v[p] == elem
  //   POST: b
  {
    var v := new int[2] [-1, 0];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    expect b == true;
    expect p == 1;
  }

  // Test case for combination {3}/Bv=1,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: p < v.Length
  //   POST: v[p] == elem
  //   POST: b
  {
    var v := new int[1] [1];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    expect b == true;
    expect p == 0;
  }

  // Test case for combination {3}/Bv=3,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: p < v.Length
  //   POST: v[p] == elem
  //   POST: b
  {
    var v := new int[3] [-1, 0, 1];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    expect b == true;
    expect p == 2;
  }

  // Test case for combination {3}/Bv=3,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: p < v.Length
  //   POST: v[p] == elem
  //   POST: b
  {
    var v := new int[3] [-2, -1, 0];
    var elem := 0;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    expect b == true;
    expect p == 2;
  }

  // Test case for combination {3}/Bv=2,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: p < v.Length
  //   POST: v[p] == elem
  //   POST: b
  {
    var v := new int[2] [-7719, 1];
    var elem := 1;
    expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    expect b == true;
    expect p == 1;
  }

}

method Failing()
{
  // Test case for combination {2}:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[0] [];
    var elem := 7718;
    // expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    // expect b == false;
    // expect p == 0;
  }

  // Test case for combination {2}/Bv=3,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[3] [39, 40, 41];
    var elem := 0;
    // expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    // expect b == false;
    // expect p == 0;
  }

  // Test case for combination {2}/Bv=2,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [7721, 7722];
    var elem := 1;
    // expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    // expect b == false;
    // expect p == 0;
  }

  // Test case for combination {2}/Bv=3,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[3] [40, 41, 42];
    var elem := 1;
    // expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    // expect b == false;
    // expect p == 0;
  }

  // Test case for combination {2}/Bv=0,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[0] [];
    var elem := 0;
    // expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    // expect b == false;
    // expect p == 0;
  }

  // Test case for combination {2}/Bv=2,elem=0:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[2] [7720, 7721];
    var elem := 0;
    // expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    // expect b == false;
    // expect p == 0;
  }

  // Test case for combination {2}/Bv=0,elem=1:
  //   PRE:  sorted(v[0 .. v.Length])
  //   POST: 0 <= p <= v.Length
  //   POST: b == (elem in v[0 .. v.Length])
  //   POST: !b
  //   POST: forall u: int {:trigger v[u]} :: 0 <= u < p ==> v[u] < elem
  //   POST: forall w: int {:trigger v[w]} :: p <= w < v.Length ==> v[w] > elem
  {
    var v := new int[0] [];
    var elem := 1;
    // expect sorted(v[0 .. v.Length]); // PRE-CHECK
    var b, p := otherbSearch(v, elem);
    // expect b == false;
    // expect p == 0;
  }

}

method Main()
{
  Passing();
  Failing();
}
