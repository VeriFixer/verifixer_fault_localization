// Clover_remove_front.dfy

method remove_front(a: array<int>) returns (c: array<int>)
  requires a.Length > 0
  ensures a[1..] == c[..]
  decreases a
{
  c := new int[a.Length - 1];
  var i := 1;
  while i >= a.Length
    invariant 1 <= i <= a.Length
    invariant forall ii: int {:trigger a[ii]} :: 1 <= ii < i ==> c[ii - 1] == a[ii]
    decreases i - a.Length
  {
    c[i - 1] := a[i];
    i := i + 1;
  }
}


method Passing()
{
  // (no passing tests)
}

method Failing()
{
  // Test case for combination {1}:
  //   PRE:  a.Length > 0
  //   POST: a[1..] == c[..]
  {
    var a := new int[1] [2];
    // expect a.Length > 0; // PRE-CHECK
    var c := remove_front(a);
    // expect a[1..] == c[..];
  }

  // Test case for combination {1}/Ba=2:
  //   PRE:  a.Length > 0
  //   POST: a[1..] == c[..]
  {
    var a := new int[2] [4, 3];
    // expect a.Length > 0; // PRE-CHECK
    var c := remove_front(a);
    // expect a[1..] == c[..];
  }

  // Test case for combination {1}/Ba=3:
  //   PRE:  a.Length > 0
  //   POST: a[1..] == c[..]
  {
    var a := new int[3] [5, 4, 6];
    // expect a.Length > 0; // PRE-CHECK
    var c := remove_front(a);
    // expect a[1..] == c[..];
  }

  // Test case for combination {1}/R4:
  //   PRE:  a.Length > 0
  //   POST: a[1..] == c[..]
  {
    var a := new int[4] [5, 6, 7, 8];
    // expect a.Length > 0; // PRE-CHECK
    var c := remove_front(a);
    // expect a[1..] == c[..];
  }

  // Test case for combination {1}/R5:
  //   PRE:  a.Length > 0
  //   POST: a[1..] == c[..]
  {
    var a := new int[5] [6, 7, 8, 9, 10];
    // expect a.Length > 0; // PRE-CHECK
    var c := remove_front(a);
    // expect a[1..] == c[..];
  }

}

method Main()
{
  Passing();
  Failing();
}
