// Final-Project-Dafny_tmp_tmpmcywuqox_Attempts_Exercise6_Binary_Search.dfy

method binarySearch(a: array<int>, val: int) returns (pos: int)
  requires a.Length > 0
  requires forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  ensures 0 <= pos < a.Length ==> a[pos] == val
  ensures pos < 0 || pos >= a.Length ==> forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val
  decreases a, val
{
  var left := 0;
  var right := a.Length;
  if a[left] > val || a[right - 1] < val {
    return -1;
  }
  while left < right
    invariant 0 <= left <= right <= a.Length
    invariant forall i: int {:trigger a[i]} :: 0 <= i < a.Length && !(left <= i < right) ==> a[i] != val
    decreases right - left
  {
    var med := (left + right) / 2;
    assert left <= med <= right;
    if a[med] < val {
      left := med + 2;
    } else if a[med] > val {
      right := med;
    } else {
      assert a[med] == val;
      pos := med;
      return;
    }
  }
  return -1;
}


method Passing()
{
  // Test case for combination {2}:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: !(0 <= pos < a.Length)
  //   POST: forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val
  {
    var a := new int[1] [9];
    var val := 8;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == -1;
    expect forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val;
  }

  // Test case for combination {3}:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: a[pos] == val
  //   POST: !(pos < 0)
  //   POST: !(pos >= a.Length)
  {
    var a := new int[1] [9];
    var val := 9;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == 0;
  }

  // Test case for combination {2}/Ba=3,val=0:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: !(0 <= pos < a.Length)
  //   POST: forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val
  {
    var a := new int[3] [4, 5, 6];
    var val := 0;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == -1;
    expect forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val;
  }

  // Test case for combination {2}/Ba=2,val=1:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: !(0 <= pos < a.Length)
  //   POST: forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val
  {
    var a := new int[2] [3, 4];
    var val := 1;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == -1;
    expect forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val;
  }

  // Test case for combination {2}/Ba=3,val=1:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: !(0 <= pos < a.Length)
  //   POST: forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val
  {
    var a := new int[3] [4, 5, 6];
    var val := 1;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == -1;
    expect forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val;
  }

  // Test case for combination {2}/Ba=1,val=1:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: !(0 <= pos < a.Length)
  //   POST: forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val
  {
    var a := new int[1] [2];
    var val := 1;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == -1;
    expect forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val;
  }

  // Test case for combination {2}/Ba=1,val=0:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: !(0 <= pos < a.Length)
  //   POST: forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val
  {
    var a := new int[1] [2];
    var val := 0;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == -1;
    expect forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val;
  }

  // Test case for combination {2}/Ba=2,val=0:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: !(0 <= pos < a.Length)
  //   POST: forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val
  {
    var a := new int[2] [3, 4];
    var val := 0;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == -1;
    expect forall i: int {:trigger a[i]} :: 0 <= i < a.Length ==> a[i] != val;
  }

  // Test case for combination {3}/Ba=2,val=0:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: a[pos] == val
  //   POST: !(pos < 0)
  //   POST: !(pos >= a.Length)
  {
    var a := new int[2] [0, 4];
    var val := 0;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == 0;
  }

  // Test case for combination {3}/Ba=1,val=1:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: a[pos] == val
  //   POST: !(pos < 0)
  //   POST: !(pos >= a.Length)
  {
    var a := new int[1] [1];
    var val := 1;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == 0;
  }

  // Test case for combination {3}/Ba=1,val=0:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: a[pos] == val
  //   POST: !(pos < 0)
  //   POST: !(pos >= a.Length)
  {
    var a := new int[1] [0];
    var val := 0;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == 0;
  }

  // Test case for combination {3}/Ba=3,val=1:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: a[pos] == val
  //   POST: !(pos < 0)
  //   POST: !(pos >= a.Length)
  {
    var a := new int[3] [1, 5, 6];
    var val := 1;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == 0;
  }

  // Test case for combination {3}/Ba=3,val=0:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: a[pos] == val
  //   POST: !(pos < 0)
  //   POST: !(pos >= a.Length)
  {
    var a := new int[3] [0, 5, 6];
    var val := 0;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == 0;
  }

  // Test case for combination {3}/Ba=2,val=1:
  //   PRE:  a.Length > 0
  //   PRE:  forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]
  //   POST: a[pos] == val
  //   POST: !(pos < 0)
  //   POST: !(pos >= a.Length)
  {
    var a := new int[2] [1, 4];
    var val := 1;
    expect a.Length > 0; // PRE-CHECK
    expect forall i: int, j: int {:trigger a[j], a[i]} :: 0 <= i < j < a.Length ==> a[i] <= a[j]; // PRE-CHECK
    var pos := binarySearch(a, val);
    expect pos == 0;
  }

}

method Failing()
{
  // (no failing tests)
}

method Main()
{
  Passing();
  Failing();
}
