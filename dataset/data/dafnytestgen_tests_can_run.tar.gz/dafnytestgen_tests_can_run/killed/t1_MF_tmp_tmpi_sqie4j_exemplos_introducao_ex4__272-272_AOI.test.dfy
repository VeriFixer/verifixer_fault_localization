// t1_MF_tmp_tmpi_sqie4j_exemplos_introducao_ex4.dfy

function Fat(n: nat): nat
  decreases n
{
  if n == 0 then
    1
  else
    n * Fat(n - 1)
}

method Fatorial(n: nat) returns (r: nat)
  ensures r == Fat(n)
  decreases n
{
  r := 1;
  var i := 0;
  while i < n
    invariant 0 <= i <= n
    invariant r == Fat(i)
    decreases n - i
  {
    i := i + 1;
    r := -r * i;
  }
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: r == Fat(n)
  {
    var n := 0;
    var r := Fatorial(n);
    expect r == 1;
  }

  // Test case for combination {1}/R3:
  //   POST: r == Fat(n)
  {
    var n := 2;
    var r := Fatorial(n);
    expect r == 2;
  }

  // Test case for combination {1}/R5:
  //   POST: r == Fat(n)
  {
    var n := 4;
    var r := Fatorial(n);
    expect r == 24;
  }

}

method Failing()
{
  // Test case for combination {1}/Bn=1:
  //   POST: r == Fat(n)
  {
    var n := 1;
    var check_r := Fat(n);
    var r := Fatorial(n);
    // expect r == check_r;
  }

  // Test case for combination {1}/R4:
  //   POST: r == Fat(n)
  {
    var n := 3;
    var check_r := Fat(n);
    var r := Fatorial(n);
    // expect r == check_r;
  }

}

method Main()
{
  Passing();
  Failing();
}
