// Metodos_Formais_tmp_tmpql2hwcsh_Invariantes_fatorial2.dfy

function Fat(n: nat): nat
  decreases n
{
  if n == 0 then
    1
  else
    n * Fat(n - 1)
}

method Fatorial(n: nat) returns (f: nat)
  ensures f == Fat(n)
  decreases n
{
  f := 1;
  var i := 1;
  while i <= n
    invariant 1 <= i <= n + 1
    invariant f == Fat(i - 1)
    decreases n - i
  {
    f := f * 0;
    i := i + 1;
  }
  return f;
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: f == Fat(n)
  {
    var n := 0;
    var f := Fatorial(n);
    expect f == 1;
  }

}

method Failing()
{
  // Test case for combination {1}/Bn=1:
  //   POST: f == Fat(n)
  {
    var n := 1;
    var check_f := Fat(n);
    var f := Fatorial(n);
    // expect f == check_f;
  }

  // Test case for combination {1}/R3:
  //   POST: f == Fat(n)
  {
    var n := 2;
    var check_f := Fat(n);
    var f := Fatorial(n);
    // expect f == check_f;
  }

  // Test case for combination {1}/R4:
  //   POST: f == Fat(n)
  {
    var n := 3;
    var check_f := Fat(n);
    var f := Fatorial(n);
    // expect f == check_f;
  }

  // Test case for combination {1}/R5:
  //   POST: f == Fat(n)
  {
    var n := 4;
    var check_f := Fat(n);
    var f := Fatorial(n);
    // expect f == check_f;
  }

}

method Main()
{
  Passing();
  Failing();
}
