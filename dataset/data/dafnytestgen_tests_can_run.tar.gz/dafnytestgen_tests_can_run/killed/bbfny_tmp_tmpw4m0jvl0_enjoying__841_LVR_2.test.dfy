// bbfny_tmp_tmpw4m0jvl0_enjoying.dfy

method MultipleReturns(x: int, y: int)
    returns (more: int, less: int)
  requires 0 < y
  ensures less < x < more
  decreases x, y
{
  more := x + y;
  less := x - y;
}

method Max(a: int, b: int) returns (c: int)
  ensures a <= c && b <= c
  ensures a == c || b == c
  decreases a, b
{
  if a > b {
    c := a;
  } else {
    c := b;
  }
}

method Testing()
{
  var x := Max(3, 15);
  assert x >= 3 && x >= 15;
  assert x == 15;
}

function max(a: int, b: int): int
  decreases a, b
{
  if a > b then
    a
  else
    b
}

method Testing'()
{
  assert max(1, 2) == 2;
  assert forall a: int, b: int {:trigger max(a, b)} :: max(a, b) == a || max(a, b) == b;
}

function abs(x: int): int
  decreases x
{
  if x < 0 then
    -x
  else
    x
}

method Abs(x: int) returns (y: int)
  ensures y == abs(x)
  decreases x
{
  return abs(x);
}

method m(n: nat)
  decreases n
{
  var i := 0;
  while i != n
    invariant 0 <= i <= n
    decreases if i <= n then n - i else i - n
  {
    i := i + 2;
  }
  assert i == n;
}

function fib(n: nat): nat
  decreases n
{
  if n == 0 then
    0
  else if n == 1 then
    1
  else
    fib(n - 1) + fib(n - 2)
}

method Find(a: array<int>, key: int) returns (index: int)
  ensures 0 <= index ==> index < a.Length && a[index] == key
  ensures index < 0 ==> forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  decreases a, key
{
  var i := 0;
  while i < a.Length
    invariant 0 <= i <= a.Length
    invariant forall k: int {:trigger a[k]} :: 0 <= k < i ==> a[k] != key
    decreases a.Length - i
  {
    if a[i] == key {
      return i;
    }
    i := i + 1;
  }
  assert i == a.Length;
  return -1;
}

method FindMax(a: array<int>) returns (i: int)
  requires a.Length >= 1
  ensures 0 <= i < a.Length
  ensures forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] <= a[i]
  decreases a
{
  i := 0;
  var max := a[i];
  var j := 1;
  while j < a.Length
    invariant 0 < j <= a.Length
    invariant i < j
    invariant max == a[i]
    invariant forall k: int {:trigger a[k]} :: 0 <= k < j ==> a[k] <= max
    decreases a.Length - j
  {
    if max < a[j] {
      max := a[j];
      i := j;
    }
    j := j + 1;
  }
}

predicate sorted(a: array<int>)
  reads a
  decreases {a}, a
{
  forall j: int, k: int {:trigger a[k], a[j]} :: 
    0 <= j < k < a.Length ==>
      a[j] < a[k]
}

predicate sorted'(a: array?<int>)
  reads a
  decreases {a}, a
{
  forall j: int, k: int {:trigger a[k], a[j]} :: 
    a != null &&
    0 <= j < k < a.Length ==>
      a[j] <= a[k]
}


method Passing()
{
  // Test case for combination {1}:
  //   PRE:  0 < y
  //   POST: less < x < more
  {
    var x := 0;
    var y := 1;
    expect 0 < y; // PRE-CHECK
    var more, less := MultipleReturns(x, y);
    expect more == 1;
    expect less == -1;
  }

  // Test case for combination {1}/Bx=1,y=1:
  //   PRE:  0 < y
  //   POST: less < x < more
  {
    var x := 1;
    var y := 1;
    expect 0 < y; // PRE-CHECK
    var more, less := MultipleReturns(x, y);
    expect more == 2;
    expect less == 0;
  }

  // Test case for combination {1}/R5:
  //   PRE:  0 < y
  //   POST: less < x < more
  {
    var x := -1;
    var y := 1;
    expect 0 < y; // PRE-CHECK
    var more, less := MultipleReturns(x, y);
    expect more == 0;
    expect less == -2;
  }

  // Test case for combination {1}:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  {
    var a := 0;
    var b := -1;
    var c := Max(a, b);
    expect c == 0;
  }

  // Test case for combination {2}:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: b == c
  {
    var a := 0;
    var b := 1;
    var c := Max(a, b);
    expect c == 1;
  }

  // Test case for combination {1}/Ba=1,b=0:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  {
    var a := 1;
    var b := 0;
    var c := Max(a, b);
    expect c == 1;
  }

  // Test case for combination {1,2}:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  //   POST: b == c
  {
    var a := 0;
    var b := 0;
    var c := Max(a, b);
    expect c == 0;
  }

  // Test case for combination {1,2}/Ba=1,b=1:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  //   POST: b == c
  {
    var a := 1;
    var b := 1;
    var c := Max(a, b);
    expect c == 1;
  }

  // Test case for combination {1}/R3:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  {
    var a := -1;
    var b := -2;
    var c := Max(a, b);
    expect c == -1;
  }

  // Test case for combination {1}/R4:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  {
    var a := 2;
    var b := -3;
    var c := Max(a, b);
    expect c == 2;
  }

  // Test case for combination {1}/R5:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  {
    var a := 1;
    var b := -4;
    var c := Max(a, b);
    expect c == 1;
  }

  // Test case for combination {2}/R2:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: b == c
  {
    var a := -1;
    var b := 2;
    var c := Max(a, b);
    expect c == 2;
  }

  // Test case for combination {2}/R3:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: b == c
  {
    var a := -2;
    var b := -1;
    var c := Max(a, b);
    expect c == -1;
  }

  // Test case for combination {2}/R4:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: b == c
  {
    var a := -3;
    var b := 3;
    var c := Max(a, b);
    expect c == 3;
  }

  // Test case for combination {2}/R5:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: b == c
  {
    var a := -4;
    var b := 2;
    var c := Max(a, b);
    expect c == 2;
  }

  // Test case for combination {1,2}/R3:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  //   POST: b == c
  {
    var a := -1;
    var b := -1;
    var c := Max(a, b);
    expect c == -1;
  }

  // Test case for combination {1,2}/R4:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  //   POST: b == c
  {
    var a := 2;
    var b := 2;
    var c := Max(a, b);
    expect c == 2;
  }

  // Test case for combination {1,2}/R5:
  //   POST: a <= c
  //   POST: b <= c
  //   POST: a == c
  //   POST: b == c
  {
    var a := -2;
    var b := -2;
    var c := Max(a, b);
    expect c == -2;
  }

  // Test case for combination {1}:
  //   POST: y == abs(x)
  {
    var x := 0;
    var y := Abs(x);
    expect y == 0;
  }

  // Test case for combination {1}/Bx=1:
  //   POST: y == abs(x)
  {
    var x := 1;
    var y := Abs(x);
    expect y == 1;
  }

  // Test case for combination {1}/R3:
  //   POST: y == abs(x)
  {
    var x := -1;
    var y := Abs(x);
    expect y == 1;
  }

  // Test case for combination {1}/R4:
  //   POST: y == abs(x)
  {
    var x := 2;
    var y := Abs(x);
    expect y == 2;
  }

  // Test case for combination {1}/R5:
  //   POST: y == abs(x)
  {
    var x := -2;
    var y := Abs(x);
    expect y == 2;
  }

  // Test case for combination {2}:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[1] [10];
    var key := 8;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {3}:
  //   POST: index < a.Length
  //   POST: a[index] == key
  //   POST: !(index < 0)
  {
    var a := new int[1] [10];
    var key := 10;
    var index := Find(a, key);
    expect index == 0;
  }

  // Test case for combination {2}/Ba=3,key=0:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[3] [4, 5, 6];
    var key := 0;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {2}/Ba=2,key=1:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[2] [3, 4];
    var key := 1;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {2}/Ba=3,key=1:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[3] [4, 5, 6];
    var key := 1;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {2}/Ba=1,key=1:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[1] [2];
    var key := 1;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {2}/Ba=1,key=0:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[1] [2];
    var key := 0;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {2}/Ba=0,key=0:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[0] [];
    var key := 0;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {2}/Ba=2,key=0:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[2] [3, 4];
    var key := 0;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {2}/Ba=0,key=1:
  //   POST: !(0 <= index)
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key
  {
    var a := new int[0] [];
    var key := 1;
    var index := Find(a, key);
    expect index == -1;
    expect forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] != key;
  }

  // Test case for combination {3}/Ba=2,key=0:
  //   POST: index < a.Length
  //   POST: a[index] == key
  //   POST: !(index < 0)
  {
    var a := new int[2] [0, 5];
    var key := 0;
    var index := Find(a, key);
    expect index == 0;
  }

  // Test case for combination {3}/Ba=1,key=1:
  //   POST: index < a.Length
  //   POST: a[index] == key
  //   POST: !(index < 0)
  {
    var a := new int[1] [1];
    var key := 1;
    var index := Find(a, key);
    expect index == 0;
  }

  // Test case for combination {3}/Ba=1,key=0:
  //   POST: index < a.Length
  //   POST: a[index] == key
  //   POST: !(index < 0)
  {
    var a := new int[1] [0];
    var key := 0;
    var index := Find(a, key);
    expect index == 0;
  }

  // Test case for combination {3}/Ba=3,key=1:
  //   POST: index < a.Length
  //   POST: a[index] == key
  //   POST: !(index < 0)
  {
    var a := new int[3] [1, 6, 7];
    var key := 1;
    var index := Find(a, key);
    expect index == 0;
  }

  // Test case for combination {3}/Ba=3,key=0:
  //   POST: index < a.Length
  //   POST: a[index] == key
  //   POST: !(index < 0)
  {
    var a := new int[3] [0, 6, 7];
    var key := 0;
    var index := Find(a, key);
    expect index == 0;
  }

  // Test case for combination {3}/Ba=2,key=1:
  //   POST: index < a.Length
  //   POST: a[index] == key
  //   POST: !(index < 0)
  {
    var a := new int[2] [1, 5];
    var key := 1;
    var index := Find(a, key);
    expect index == 0;
  }

  // Test case for combination {1}:
  //   PRE:  a.Length >= 1
  //   POST: 0 <= i < a.Length
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] <= a[i]
  {
    var a := new int[1] [38];
    expect a.Length >= 1; // PRE-CHECK
    var i := FindMax(a);
    expect i == 0;
  }

  // Test case for combination {1}/Ba=2:
  //   PRE:  a.Length >= 1
  //   POST: 0 <= i < a.Length
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] <= a[i]
  {
    var a := new int[2] [35472, 35473];
    expect a.Length >= 1; // PRE-CHECK
    var i := FindMax(a);
    expect i == 1;
  }

  // Test case for combination {1}/Ba=3:
  //   PRE:  a.Length >= 1
  //   POST: 0 <= i < a.Length
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] <= a[i]
  {
    var a := new int[3] [23675, 23674, 23676];
    expect a.Length >= 1; // PRE-CHECK
    var i := FindMax(a);
    expect i == 2;
  }

  // Test case for combination {1}/R4:
  //   PRE:  a.Length >= 1
  //   POST: 0 <= i < a.Length
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] <= a[i]
  {
    var a := new int[4] [-7719, -21238, -2437, 38];
    expect a.Length >= 1; // PRE-CHECK
    var i := FindMax(a);
    expect i == 3;
  }

  // Test case for combination {1}/R5:
  //   PRE:  a.Length >= 1
  //   POST: 0 <= i < a.Length
  //   POST: forall k: int {:trigger a[k]} :: 0 <= k < a.Length ==> a[k] <= a[i]
  {
    var a := new int[5] [-7719, -21238, -2437, -8855, 38];
    expect a.Length >= 1; // PRE-CHECK
    var i := FindMax(a);
    expect i == 4;
  }

}

method Failing()
{
  // Test case for combination {1}/Bx=0,y=2:
  //   PRE:  0 < y
  //   POST: less < x < more
  {
    var x := 0;
    var y := 2;
    // expect 0 < y; // PRE-CHECK
    var more, less := MultipleReturns(x, y);
    // expect more == 1;
    // expect less == -1;
  }

  // Test case for combination {1}/Bx=1,y=2:
  //   PRE:  0 < y
  //   POST: less < x < more
  {
    var x := 1;
    var y := 2;
    // expect 0 < y; // PRE-CHECK
    var more, less := MultipleReturns(x, y);
    // expect more == 2;
    // expect less == 0;
  }

}

method Main()
{
  Passing();
  Failing();
}
