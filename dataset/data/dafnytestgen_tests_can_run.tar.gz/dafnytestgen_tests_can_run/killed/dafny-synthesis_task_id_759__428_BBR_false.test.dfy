// dafny-synthesis_task_id_759.dfy

method IsDecimalWithTwoPrecision(s: string) returns (result: bool)
  ensures result ==> exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  ensures !result ==> !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  decreases s
{
  result := false;
  for i: int := 0 to |s|
    invariant 0 <= i <= |s|
    invariant result <==> exists k: int {:trigger s[k]} :: 0 <= k < i && s[k] == '.' && |s| - k - 1 == 2
  {
    if false && |s| - i - 1 == 2 {
      result := true;
      break;
    }
  }
}


method Passing()
{
  // Test case for combination {2}:
  //   POST: !result
  //   POST: !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  {
    var s: seq<char> := [];
    var result := IsDecimalWithTwoPrecision(s);
    expect result == false;
    expect !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

  // Test case for combination {2}/Bs=3:
  //   POST: !result
  //   POST: !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  {
    var s: seq<char> := [' ', '!', '"'];
    var result := IsDecimalWithTwoPrecision(s);
    expect result == false;
    expect !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

  // Test case for combination {2}/Bs=1:
  //   POST: !result
  //   POST: !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  {
    var s: seq<char> := [' '];
    var result := IsDecimalWithTwoPrecision(s);
    expect result == false;
    expect !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

  // Test case for combination {2}/Bs=2:
  //   POST: !result
  //   POST: !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  {
    var s: seq<char> := [' ', '!'];
    var result := IsDecimalWithTwoPrecision(s);
    expect result == false;
    expect !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

  // Test case for combination {2}/R5:
  //   POST: !result
  //   POST: !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  {
    var s: seq<char> := ['%', '/', ' ', 'f'];
    var result := IsDecimalWithTwoPrecision(s);
    expect result == false;
    expect !exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

}

method Failing()
{
  // Test case for combination {3}:
  //   POST: exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  //   POST: result
  {
    var s: seq<char> := ['.', '!', ' '];
    var result := IsDecimalWithTwoPrecision(s);
    // expect result == true;
    // expect exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

  // Test case for combination {3}/R2:
  //   POST: exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  //   POST: result
  {
    var s: seq<char> := ['1', '.', ' ', '/'];
    var result := IsDecimalWithTwoPrecision(s);
    // expect result == true;
    // expect exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

  // Test case for combination {3}/R3:
  //   POST: exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  //   POST: result
  {
    var s: seq<char> := ['4', '%', '.', ' ', '/'];
    var result := IsDecimalWithTwoPrecision(s);
    // expect result == true;
    // expect exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

  // Test case for combination {3}/R4:
  //   POST: exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  //   POST: result
  {
    var s: seq<char> := [' ', '%', ' ', '/', '.', 'T', '!'];
    var result := IsDecimalWithTwoPrecision(s);
    // expect result == true;
    // expect exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

  // Test case for combination {3}/R5:
  //   POST: exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2
  //   POST: result
  {
    var s: seq<char> := [' ', ' ', 'Z', '.', '{', '-'];
    var result := IsDecimalWithTwoPrecision(s);
    // expect result == true;
    // expect exists i: int {:trigger s[i]} :: 0 <= i < |s| && s[i] == '.' && |s| - i - 1 == 2;
  }

}

method Main()
{
  Passing();
  Failing();
}
