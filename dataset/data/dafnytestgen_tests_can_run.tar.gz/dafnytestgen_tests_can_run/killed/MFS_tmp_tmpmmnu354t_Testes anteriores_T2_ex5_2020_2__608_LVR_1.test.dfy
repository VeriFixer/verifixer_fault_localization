// MFS_tmp_tmpmmnu354t_Testes anteriores_T2_ex5_2020_2.dfy

method leq(a: array<int>, b: array<int>) returns (result: bool)
  ensures result <==> (a.Length <= b.Length && a[..] == b[..a.Length]) || exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  decreases a, b
{
  var i := 0;
  while i < a.Length && i < b.Length
    invariant 0 <= i <= a.Length && 0 <= i <= b.Length
    invariant a[..i] == b[..i]
    decreases a.Length - i
  {
    if a[i] < b[i] {
      return true;
    } else if a[i] > b[i] {
      return false;
    } else {
      i := i + 1;
    }
  }
  return a.Length <= b.Length;
}

method testLeq()
{
  var b := new int[] [1, 2];
  var a1 := new int[] [];
  var r1 := leq(a1, b);
  assert r1;
  var a2 := new int[] [1];
  var r2 := leq(a2, b);
  assert r2;
  var a3 := new int[] [1, 2];
  var r3 := leq(a3, b);
  assert r3;
  var a4 := new int[] [1, 1, 2];
  var r4 := leq(a4, b);
  assert a4[1] < b[1] && r4;
  var a5 := new int[] [1, 2, 3];
  var r5 := leq(a5, b);
  assert !r5;
  var a6 := new int[] [2];
  var r6 := leq(a6, b);
  assert !r6;
}


method Passing()
{
  // Test case for combination {1}:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[0] [];
    var b := new int[0] [];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {2}:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[1] [40650];
    var b := new int[1] [40651];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {4}:
  //   POST: !result
  //   POST: !(a[..] == b[..a.Length])
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[1] [2437];
    var b := new int[1] [2436];
    var result := leq(a, b);
    expect result == false;
    expect !(a[..] == b[..a.Length]);
    expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {1}/Ba=3,b=3:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[3] [0, 7721, 7720];
    var b := new int[3] [0, 7721, 7720];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {1}/Ba=2,b=2:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[2] [0, -1];
    var b := new int[2] [0, -1];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {1}/Ba=2,b=3:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[2] [28957, 28958];
    var b := new int[3] [28957, 28958, 8];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {1}/Ba=1,b=3:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[1] [0];
    var b := new int[3] [0, 6, 7];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {1}/Ba=1,b=2:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[1] [0];
    var b := new int[2] [0, 5];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {1}/Ba=1,b=1:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[1] [0];
    var b := new int[1] [0];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {1}/Ba=0,b=3:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[0] [];
    var b := new int[3] [5, 4, 6];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {1}/Ba=0,b=2:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[0] [];
    var b := new int[2] [4, 3];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {1}/Ba=0,b=1:
  //   POST: result
  //   POST: a.Length <= b.Length
  //   POST: a[..] == b[..a.Length]
  {
    var a := new int[0] [];
    var b := new int[1] [2];
    var result := leq(a, b);
    expect result == true;
    expect a.Length <= b.Length;
    expect a[..] == b[..a.Length];
  }

  // Test case for combination {2}/Ba=2,b=2:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[2] [2435, 2436];
    var b := new int[2] [2436, 2437];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {2}/Ba=3,b=2:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[3] [2435, 2436, 8];
    var b := new int[2] [2436, 2437];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {2}/Ba=3,b=1:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[3] [28957, 6, 7];
    var b := new int[1] [28958];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {2}/Ba=2,b=3:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[2] [2435, 2436];
    var b := new int[3] [2436, 2437, 8];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {2}/Ba=2,b=1:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[2] [28957, 5];
    var b := new int[1] [28958];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {2}/Ba=3,b=3:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[3] [8853, 8854, 8855];
    var b := new int[3] [8854, 8855, 8856];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {2}/Ba=1,b=3:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[1] [28957];
    var b := new int[3] [28958, 6, 7];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {2}/Ba=1,b=2:
  //   POST: result
  //   POST: exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[1] [28957];
    var b := new int[2] [28958, 5];
    var result := leq(a, b);
    expect result == true;
    expect exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {4}/Ba=1,b=2:
  //   POST: !result
  //   POST: !(a[..] == b[..a.Length])
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[1] [7719];
    var b := new int[2] [-38, 5];
    var result := leq(a, b);
    expect result == false;
    expect !(a[..] == b[..a.Length]);
    expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {4}/Ba=2,b=2:
  //   POST: !result
  //   POST: !(a[..] == b[..a.Length])
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[2] [7719, 7718];
    var b := new int[2] [7718, 7719];
    var result := leq(a, b);
    expect result == false;
    expect !(a[..] == b[..a.Length]);
    expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {4}/Ba=2,b=3:
  //   POST: !result
  //   POST: !(a[..] == b[..a.Length])
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[2] [7719, 7720];
    var b := new int[3] [7718, 7719, 8];
    var result := leq(a, b);
    expect result == false;
    expect !(a[..] == b[..a.Length]);
    expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {4}/Ba=3,b=3:
  //   POST: !result
  //   POST: !(a[..] == b[..a.Length])
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[3] [8856, 8857, 8858];
    var b := new int[3] [8855, 8858, 8859];
    var result := leq(a, b);
    expect result == false;
    expect !(a[..] == b[..a.Length]);
    expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

  // Test case for combination {4}/Ba=1,b=3:
  //   POST: !result
  //   POST: !(a[..] == b[..a.Length])
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  {
    var a := new int[1] [7719];
    var b := new int[3] [-38, 6, 7];
    var result := leq(a, b);
    expect result == false;
    expect !(a[..] == b[..a.Length]);
    expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
  }

}

method Failing()
{
  // Test case for combination {3,4}:
  //   POST: !result
  //   POST: !(a.Length <= b.Length)
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  //   POST: !(a[..] == b[..a.Length])
  {
    var a := new int[1] [2437];
    var b := new int[0] [];
    var result := leq(a, b);
    // expect result == false;
    // expect !(a.Length <= b.Length);
    // expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
    // expect !(a[..] == b[..a.Length]);
  }

  // Test case for combination {3,4}/Ba=2,b=0:
  //   POST: !result
  //   POST: !(a.Length <= b.Length)
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  //   POST: !(a[..] == b[..a.Length])
  {
    var a := new int[2] [4, 3];
    var b := new int[0] [];
    var result := leq(a, b);
    // expect result == false;
    // expect !(a.Length <= b.Length);
    // expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
    // expect !(a[..] == b[..a.Length]);
  }

  // Test case for combination {3,4}/Ba=3,b=2:
  //   POST: !result
  //   POST: !(a.Length <= b.Length)
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  //   POST: !(a[..] == b[..a.Length])
  {
    var a := new int[3] [7719, 7720, 8];
    var b := new int[2] [7718, 7719];
    var result := leq(a, b);
    // expect result == false;
    // expect !(a.Length <= b.Length);
    // expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
    // expect !(a[..] == b[..a.Length]);
  }

  // Test case for combination {3,4}/Ba=3,b=1:
  //   POST: !result
  //   POST: !(a.Length <= b.Length)
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  //   POST: !(a[..] == b[..a.Length])
  {
    var a := new int[3] [7719, 6, 7];
    var b := new int[1] [-38];
    var result := leq(a, b);
    // expect result == false;
    // expect !(a.Length <= b.Length);
    // expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
    // expect !(a[..] == b[..a.Length]);
  }

  // Test case for combination {3,4}/Ba=3,b=0:
  //   POST: !result
  //   POST: !(a.Length <= b.Length)
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  //   POST: !(a[..] == b[..a.Length])
  {
    var a := new int[3] [5, 4, 6];
    var b := new int[0] [];
    var result := leq(a, b);
    // expect result == false;
    // expect !(a.Length <= b.Length);
    // expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
    // expect !(a[..] == b[..a.Length]);
  }

  // Test case for combination {3,4}/Ba=2,b=1:
  //   POST: !result
  //   POST: !(a.Length <= b.Length)
  //   POST: !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k]
  //   POST: !(a[..] == b[..a.Length])
  {
    var a := new int[2] [7719, 5];
    var b := new int[1] [-38];
    var result := leq(a, b);
    // expect result == false;
    // expect !(a.Length <= b.Length);
    // expect !exists k: int {:trigger b[k]} {:trigger a[k]} {:trigger b[..k]} {:trigger a[..k]} :: 0 <= k < a.Length && k < b.Length && a[..k] == b[..k] && a[k] < b[k];
    // expect !(a[..] == b[..a.Length]);
  }

}

method Main()
{
  Passing();
  Failing();
}
