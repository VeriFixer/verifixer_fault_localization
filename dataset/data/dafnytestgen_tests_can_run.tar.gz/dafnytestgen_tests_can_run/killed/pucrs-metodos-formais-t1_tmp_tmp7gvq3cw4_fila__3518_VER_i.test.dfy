// pucrs-metodos-formais-t1_tmp_tmp7gvq3cw4_fila.dfy

method Main()
{
  var fila := new Fila();
  fila.enfileira(1);
  fila.enfileira(2);
  fila.enfileira(3);
  fila.enfileira(4);
  assert fila.Conteudo == [1, 2, 3, 4];
  var q := fila.tamanho();
  assert q == 4;
  var e := fila.desenfileira();
  assert e == 1;
  assert fila.Conteudo == [2, 3, 4];
  assert fila.tamanho() == 3;
  assert fila.Conteudo == [2, 3, 4];
  var r := fila.contem(1);
  assert r == false;
  assert fila.a[0] == 2;
  var r2 := fila.contem(2);
  assert r2 == true;
  var vazia := fila.estaVazia();
  assert vazia == false;
  var outraFila := new Fila();
  vazia := outraFila.estaVazia();
  assert vazia == true;
  assert fila.Conteudo == [2, 3, 4];
  outraFila.enfileira(5);
  outraFila.enfileira(6);
  outraFila.enfileira(7);
  assert outraFila.Conteudo == [5, 6, 7];
  var concatenada := fila.concat(outraFila);
  assert concatenada.Conteudo == [2, 3, 4, 5, 6, 7];
}

class {:autocontracts} Fila {
  var a: array<int>
  var cauda: nat
  const defaultSize: nat
  var Conteudo: seq<int>

  predicate Valid()
    reads this, Repr
    ensures Valid() ==> this in Repr
    decreases Repr + {this}
  {
    this in Repr &&
    null !in Repr &&
    a in Repr &&
    defaultSize > 0 &&
    a.Length >= defaultSize &&
    0 <= cauda <= a.Length &&
    Conteudo == a[0 .. cauda]
  }

  constructor ()
    ensures Valid()
    ensures fresh(Repr)
    ensures Conteudo == []
    ensures defaultSize == 3
    ensures a.Length == 3
    ensures fresh(a)
  {
    defaultSize := 3;
    a := new int[3];
    cauda := 0;
    Conteudo := [];
    new;
    Repr := {this};
    if !(a in Repr) {
      Repr := Repr + {a};
    }
  }

  function tamanho(): nat
    requires Valid()
    reads Repr
    ensures tamanho() == |Conteudo|
    decreases Repr
  {
    cauda
  }

  function estaVazia(): bool
    requires Valid()
    reads Repr
    ensures estaVazia() <==> |Conteudo| == 0
    decreases Repr
  {
    cauda == 0
  }

  method enfileira(e: int)
    requires Valid()
    modifies Repr
    ensures Valid()
    ensures fresh(Repr - old(Repr))
    ensures Conteudo == old(Conteudo) + [e]
    decreases e
  {
    if cauda == a.Length {
      var novoArray := new int[cauda + defaultSize];
      var i := 0;
      forall i: int | 0 <= i < a.Length {
        novoArray[i] := a[i];
      }
      a := novoArray;
    }
    a[cauda] := e;
    cauda := cauda + 1;
    Conteudo := Conteudo + [e];
    if !(a in Repr) {
      Repr := Repr + {a};
    }
  }

  method desenfileira() returns (e: int)
    requires Valid()
    requires |Conteudo| > 0
    modifies Repr
    ensures Valid()
    ensures fresh(Repr - old(Repr))
    ensures e == old(Conteudo)[0]
    ensures Conteudo == old(Conteudo)[1..]
  {
    e := a[0];
    cauda := cauda - 1;
    forall i: int | 0 <= i < cauda {
      a[i] := a[i + 1];
    }
    Conteudo := a[0 .. cauda];
    if !(a in Repr) {
      Repr := Repr + {a};
    }
  }

  method contem(e: int) returns (r: bool)
    requires Valid()
    ensures r <==> exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
    decreases e
  {
    var i := 0;
    r := false;
    while i < cauda
      invariant 0 <= i <= cauda
      invariant forall j: nat {:trigger a[j]} :: j < i ==> a[j] != e
      decreases cauda - i
    {
      if a[i] == e {
        r := true;
        return;
      }
      i := i + 1;
    }
    return r;
  }

  method concat(f2: Fila) returns (r: Fila)
    requires Valid()
    requires Valid()
    requires f2.Valid()
    ensures r.Conteudo == Conteudo + f2.Conteudo
    decreases f2
  {
    r := new Fila();
    var i := 0;
    while i < cauda
      invariant 0 <= i <= cauda
      invariant 0 <= i <= r.cauda
      invariant r.cauda <= r.a.Length
      invariant fresh(r.Repr)
      invariant r.Valid()
      invariant r.Conteudo == Conteudo[0 .. i]
      decreases cauda - i
    {
      var valor := a[i];
      r.enfileira(valor);
      i := i + 1;
    }
    var j := 0;
    while j < f2.cauda
      invariant 0 <= j <= f2.cauda
      invariant 0 <= j <= r.cauda
      invariant r.cauda <= r.a.Length
      invariant fresh(r.Repr)
      invariant r.Valid()
      invariant r.Conteudo == Conteudo + f2.Conteudo[0 .. j]
      decreases f2.cauda - j
    {
      var valor := f2.a[j];
      r.enfileira(valor);
      j := i + 1;
    }
  }

  var Repr: set<object?>
}


method GeneratedTests_enfileira()
{
  // Test case for combination {1}:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 0;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=0,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=0,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=0,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=0,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=0,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=1,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=1,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=1,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=1,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=1,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=1,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=2,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=2,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=2,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=2,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=2,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=2,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=3,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=3,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=3,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=3,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=3,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=3,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=3,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=0,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=0,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=0,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=0,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=0,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=0,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=1,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=1,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=1,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=1,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=1,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=1,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=2,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=2,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=2,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=2,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=2,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=2,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=3,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=3,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=1,a=3,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

  // Test case for combination {1}/Be=2,a=3,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: Valid()
  //   POST: Conteudo == old(Conteudo) + [e]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    obj.enfileira(e);
    expect obj.Valid();
    expect Conteudo == old(Conteudo) + [e];
  }

}

method GeneratedTests_desenfileira()
{
  // Test case for combination {1}:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=3,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=3,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=3,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=3,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=2,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=2,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=2,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=2,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=3,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=1,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=1,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=1,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=1,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=0,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=0,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=0,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=0,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=1,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

  // Test case for combination {1}/Ba=3,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  |Conteudo| > 0
  //   POST: Valid()
  //   POST: e == old(Conteudo)[0]
  //   POST: Conteudo == old(Conteudo)[1..]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    expect obj.Valid(); // PRE-CHECK
    expect |Conteudo| > 0; // PRE-CHECK
    var e := obj.desenfileira();
    expect obj.Valid();
    expect e == 0;
    expect Conteudo == old(Conteudo)[1..];
  }

}

method GeneratedTests_contem()
{
  // Test case for combination {1}:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 7;
    obj.Repr := {obj, obj.a};
    var e := 14;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [9];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 8;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=0,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=0,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=0,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=0,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=1,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=1,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=1,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [15];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=2,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [2, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=2,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [2, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=2,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [14, 13];
    obj.a := tmp_a;
    obj.cauda := 6;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=2,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [14, 13];
    obj.a := tmp_a;
    obj.cauda := 6;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=3,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [2, 4, 5];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=3,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [2, 4, 5];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=3,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [14, 13, 15];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=3,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [14, 13, 15];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=2,a=1,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [15];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=3,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [14, 13, 15];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=3,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [14, 13, 15];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=0,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=0,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=0,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=0,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=1,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [1];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=1,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [1];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=1,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [15];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=1,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [15];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=3,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [1, 4, 5];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=2,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [15, 14];
    obj.a := tmp_a;
    obj.cauda := 8;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=3,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [1, 4, 5];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=2,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [1, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=2,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [1, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {1}/Be=1,a=2,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: r
  //   POST: exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [14, 13];
    obj.a := tmp_a;
    obj.cauda := 6;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == true;
    expect exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=1,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [15];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=0,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=0,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=1,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=1,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=1,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=1,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [15];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=2,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=2,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [15, 14];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=2,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [3, 4];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=2,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [3, 4];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=2,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [15, 14];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=3,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=3,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=3,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [4, 5, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=3,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [4, 5, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=3,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [14, 13, 15];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=2,a=3,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [14, 13, 15];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 2;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=3,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [14, 13, 15];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=3,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [14, 13, 15];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=0,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=0,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=1,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=1,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=1,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=1,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=1,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [15];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=1,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[1] [15];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=2,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=2,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [3, 4];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=2,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [3, 4];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=2,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [15, 14];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=2,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[2] [15, 14];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=3,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [4, 5, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

  // Test case for combination {2}/Be=1,a=3,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   POST: !r
  //   POST: !exists i: int {:trigger a[i]} :: 0 <= i < cauda && e == a[i]
  {
    var obj := new Fila();
    var tmp_a := new int[3] [4, 5, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var e := 1;
    expect obj.Valid(); // PRE-CHECK
    var r := obj.contem(e);
    expect r == false;
    expect !exists i: int {:trigger obj.a[i]} :: 0 <= i < obj.cauda && e == obj.a[i];
  }

}

method GeneratedTests_concat()
{
  // Test case for combination {1}:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=3,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=3,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=3,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=3,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=2,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=2,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=2,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=2,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=2,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 1;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=2,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[2] [4, 3];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 1;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=3,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var f2 := 1;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=1,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=1,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=1,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=1,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 1;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=1,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[1] [2];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=0,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=0,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=0,cauda=1,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=0,cauda=1,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 1;
    obj.Repr := {obj, obj.a};
    var f2 := 0;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=0,cauda=0,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 1;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=0,cauda=0,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[0] [];
    obj.a := tmp_a;
    obj.cauda := 0;
    obj.Repr := {obj, obj.a};
    var f2 := 1;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=1,cauda==a,defaultSize=1:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[1] [3];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var f2 := 1;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

  // Test case for combination {1}/Ba=3,cauda==a,defaultSize=2:
  //   PRE:  Valid()
  //   PRE:  Valid()
  //   PRE:  f2.Valid()
  //   POST: r.Conteudo == Conteudo + f2.Conteudo
  {
    var obj := new Fila();
    var tmp_a := new int[3] [5, 4, 6];
    obj.a := tmp_a;
    obj.cauda := 2;
    obj.Repr := {obj, obj.a};
    var f2 := 1;
    expect obj.Valid(); // PRE-CHECK
    expect obj.Valid(); // PRE-CHECK
    expect f2.Valid(); // PRE-CHECK
    var r := obj.concat(f2);
    expect r.Conteudo == Conteudo + f2.Conteudo;
  }

}
