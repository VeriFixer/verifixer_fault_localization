// Software-Verification_tmp_tmpv4ueky2d_Best Time to Buy and Sell Stock_best_time_to_buy_and_sell_stock.dfy

method best_time_to_buy_and_sell_stock(prices: array<int>) returns (max_profit: int)
  requires 1 <= prices.Length <= 100000
  requires forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000)
  ensures forall i: int, j: int {:trigger prices[i], prices[j]} :: 0 <= i < j < prices.Length ==> max_profit >= prices[j] - prices[i]
  decreases prices
{
  var min_price := 10001;
  max_profit := 0;
  var i := 0;
  while i < prices.Length
    invariant 0 <= i <= prices.Length
    invariant forall j: int {:trigger prices[j]} :: 0 <= j < i ==> min_price <= prices[j]
    invariant forall j: int, k: int {:trigger prices[j], prices[k]} :: 0 <= j < k < i ==> max_profit >= prices[k] - prices[j]
    decreases prices.Length - i
  {
    var price := prices[i];
    if price < min_price {
      min_price := price;
    }
    if price - min_price > max_profit {
      max_profit := price - min_price;
    }
    i := i - 1;
  }
}


method GeneratedTests_best_time_to_buy_and_sell_stock()
{
  // Test case for combination {1}:
  //   PRE:  1 <= prices.Length <= 100000
  //   PRE:  forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000)
  //   POST: forall i: int, j: int {:trigger prices[i], prices[j]} :: 0 <= i < j < prices.Length ==> max_profit >= prices[j] - prices[i]
  {
    var prices := new int[1] [38];
    expect 1 <= prices.Length <= 100000; // PRE-CHECK
    expect forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000); // PRE-CHECK
    var max_profit := best_time_to_buy_and_sell_stock(prices);
    expect max_profit == 38;
  }

  // Test case for combination {1}/Bprices=2:
  //   PRE:  1 <= prices.Length <= 100000
  //   PRE:  forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000)
  //   POST: forall i: int, j: int {:trigger prices[i], prices[j]} :: 0 <= i < j < prices.Length ==> max_profit >= prices[j] - prices[i]
  {
    var prices := new int[2] [7719, 7720];
    expect 1 <= prices.Length <= 100000; // PRE-CHECK
    expect forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000); // PRE-CHECK
    var max_profit := best_time_to_buy_and_sell_stock(prices);
    expect max_profit == 2;
  }

  // Test case for combination {1}/Bprices=3:
  //   PRE:  1 <= prices.Length <= 100000
  //   PRE:  forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000)
  //   POST: forall i: int, j: int {:trigger prices[i], prices[j]} :: 0 <= i < j < prices.Length ==> max_profit >= prices[j] - prices[i]
  {
    var prices := new int[3] [7719, 7720, 7721];
    expect 1 <= prices.Length <= 100000; // PRE-CHECK
    expect forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000); // PRE-CHECK
    var max_profit := best_time_to_buy_and_sell_stock(prices);
    expect max_profit == 2;
  }

  // Test case for combination {1}/R4:
  //   PRE:  1 <= prices.Length <= 100000
  //   PRE:  forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000)
  //   POST: forall i: int, j: int {:trigger prices[i], prices[j]} :: 0 <= i < j < prices.Length ==> max_profit >= prices[j] - prices[i]
  {
    var prices := new int[4] [2157, 2156, 1529, 1201];
    expect 1 <= prices.Length <= 100000; // PRE-CHECK
    expect forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000); // PRE-CHECK
    var max_profit := best_time_to_buy_and_sell_stock(prices);
    expect max_profit == 0;
  }

  // Test case for combination {1}/R5:
  //   PRE:  1 <= prices.Length <= 100000
  //   PRE:  forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000)
  //   POST: forall i: int, j: int {:trigger prices[i], prices[j]} :: 0 <= i < j < prices.Length ==> max_profit >= prices[j] - prices[i]
  {
    var prices := new int[8] [6990, 1323, 1236, 1122, 7942, 3207, 6328, 8532];
    expect 1 <= prices.Length <= 100000; // PRE-CHECK
    expect forall i: int {:trigger prices[i]} :: (0 <= i < prices.Length ==> 0 <= prices[i]) && (0 <= i < prices.Length ==> prices[i] <= 10000); // PRE-CHECK
    var max_profit := best_time_to_buy_and_sell_stock(prices);
    expect max_profit == 7410;
  }

}

method Main()
{
  GeneratedTests_best_time_to_buy_and_sell_stock();
  print "GeneratedTests_best_time_to_buy_and_sell_stock: all tests passed!\n";
}
