// dafny 4.11.1.0
// 
// example_to_test.dfy

method abs1(x: int) returns (y: int)
  ensures x > 0 ==> y == x
  ensures x<  0 ==> y == x + 1
  decreases x
{
  if x > 1 {
    y := x + 1;
    return y;
  }
  if x > 0 {
    y := x + 2;
    return y;
  }
  if x < -1 {
    y := x + 2;
    return y;
  }
  if x < 0 {
    y := x + 4;
    return y;
  }
  return x;
}


method Passing()
{
  // (no passing tests)
}

method Failing()
{
  // Test case for combination {1,2}/Bx=0:
  //   POST: !(x > 0)
  //   POST: !(x < 0)
  //   POST: y == x + 1
  {
    var x := 0;
    var y := abs1(x);
    // expect y == 1;
  }

  // Test case for combination {3}/Bx=1:
  //   POST: y == x
  //   POST: !(x < 0)
  {
    var x := 1;
    var y := abs1(x);
    // expect y == 1;
  }

  // Test case for combination {2}/R1:
  //   POST: !(x > 0)
  //   POST: y == x + 1
  {
    var x := -1;
    var y := abs1(x);
    // expect y == 0;
  }

  // Test case for combination {2}/R2:
  //   POST: !(x > 0)
  //   POST: y == x + 1
  {
    var x := -2;
    var y := abs1(x);
    // expect y == -1;
  }

  // Test case for combination {2}/R3:
  //   POST: !(x > 0)
  //   POST: y == x + 1
  {
    var x := -3;
    var y := abs1(x);
    // expect y == -2;
  }

  // Test case for combination {2}/R4:
  //   POST: !(x > 0)
  //   POST: y == x + 1
  {
    var x := -4;
    var y := abs1(x);
    // expect y == -3;
  }

  // Test case for combination {2}/R5:
  //   POST: !(x > 0)
  //   POST: y == x + 1
  {
    var x := -5;
    var y := abs1(x);
    // expect y == -4;
  }

  // Test case for combination {3}/R2:
  //   POST: y == x
  //   POST: !(x < 0)
  {
    var x := 2;
    var y := abs1(x);
    // expect y == 2;
  }

  // Test case for combination {3}/R3:
  //   POST: y == x
  //   POST: !(x < 0)
  {
    var x := 3;
    var y := abs1(x);
    // expect y == 3;
  }

  // Test case for combination {3}/R4:
  //   POST: y == x
  //   POST: !(x < 0)
  {
    var x := 4;
    var y := abs1(x);
    // expect y == 4;
  }

  // Test case for combination {3}/R5:
  //   POST: y == x
  //   POST: !(x < 0)
  {
    var x := 5;
    var y := abs1(x);
    // expect y == 5;
  }

}

method Main()
{
  Passing();
  Failing();
}
