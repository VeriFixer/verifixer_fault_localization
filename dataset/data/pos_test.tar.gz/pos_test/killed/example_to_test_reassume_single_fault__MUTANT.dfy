// dafny 4.11.1.0
// 
// example_to_test.dfy

method abs1(x: int) returns (y: int)
  ensures x > 0 ==> y == x
  decreases x
{
  y := x;
  if(x > 20){ // FAULT HERE (if is x > 20 it works)
    y := x;
  } else {
    if(x > 10){
      y := x+1;
    } else {
      y := x+2;
    }
  }
  return y;
}
