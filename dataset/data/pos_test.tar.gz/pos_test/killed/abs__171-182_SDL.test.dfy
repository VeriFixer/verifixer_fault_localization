// abs.dfy

method absplus1(x: int) returns (y: int)
  ensures x > 0 ==> y == x + 1
  ensures x <= 0 ==> y == -x + 1
  decreases x
{
  if x > 0 {
    y := x + 1;
  } else {
  }
}


method Passing()
{
  // (no passing tests)
}

method Failing()
{
  // Test case for combination {3}/Bx=1:
  //   POST: y == x + 1
  //   POST: !(x <= 0)
  {
    var x := 1;
    var y := absplus1(x);
    // expect y == 2;
  }

  // Test case for combination {2,4}/Bx=0:
  //   POST: !(x > 0)
  //   POST: y == -x + 1
  //   POST: y == x + 1
  {
    var x := 0;
    var y := absplus1(x);
    // expect y == 1;
  }

  // Test case for combination {2}/R1:
  //   POST: !(x > 0)
  //   POST: y == -x + 1
  {
    var x := -1;
    var y := absplus1(x);
    // expect y == 2;
  }

  // Test case for combination {2}/R2:
  //   POST: !(x > 0)
  //   POST: y == -x + 1
  {
    var x := -2;
    var y := absplus1(x);
    // expect y == 3;
  }

  // Test case for combination {2}/R3:
  //   POST: !(x > 0)
  //   POST: y == -x + 1
  {
    var x := -3;
    var y := absplus1(x);
    // expect y == 4;
  }

  // Test case for combination {2}/R4:
  //   POST: !(x > 0)
  //   POST: y == -x + 1
  {
    var x := -4;
    var y := absplus1(x);
    // expect y == 5;
  }

  // Test case for combination {2}/R5:
  //   POST: !(x > 0)
  //   POST: y == -x + 1
  {
    var x := -5;
    var y := absplus1(x);
    // expect y == 6;
  }

  // Test case for combination {3}/R2:
  //   POST: y == x + 1
  //   POST: !(x <= 0)
  {
    var x := 2;
    var y := absplus1(x);
    // expect y == 3;
  }

  // Test case for combination {3}/R3:
  //   POST: y == x + 1
  //   POST: !(x <= 0)
  {
    var x := 3;
    var y := absplus1(x);
    // expect y == 4;
  }

  // Test case for combination {3}/R4:
  //   POST: y == x + 1
  //   POST: !(x <= 0)
  {
    var x := 4;
    var y := absplus1(x);
    // expect y == 5;
  }

  // Test case for combination {3}/R5:
  //   POST: y == x + 1
  //   POST: !(x <= 0)
  {
    var x := 5;
    var y := absplus1(x);
    // expect y == 6;
  }

}

method Main()
{
  Passing();
  Failing();
}
