// dafny 4.11.1.0
// 
// example_to_test.dfy

method abs1(x: int) returns (y: int)
  ensures x > 0 ==> y == x
  decreases x
{
  y := x;
  if(x > 20){ // FAULT HERE (if is x > 20 it works)
    y := x;
  } else {
    if(x > 10){
      y := x+1;
    } else {
      y := x+2;
    }
  }
  return y;
}


method Passing()
{
  // (no passing tests)
  var x := 30;
  var y := abs1(x);
  expect(x == y);
}

method Failing()
{
  // Test case for combination {1,2}:
  //   POST: !(x > 0)
  //   POST: y == x
  {
    var x := 0;
    var y := abs1(x);
    // expect y == 0;
    // expect !(x > 0);
  }

  // Test case for combination {2}:
  //   POST: y == x
  {
    var x := 1;
    var y := abs1(x);
    // expect y == 1;
  }

  // Test case for combination {1,2}/R2:
  //   POST: !(x > 0)
  //   POST: y == x
  {
    var x := -1;
    var y := abs1(x);
    // expect y == -1;
    // expect !(x > 0);
  }

  // Test case for combination {1,2}/R3:
  //   POST: !(x > 0)
  //   POST: y == x
  {
    var x := -2;
    var y := abs1(x);
    // expect y == -2;
    // expect !(x > 0);
  }

  // Test case for combination {1,2}/R4:
  //   POST: !(x > 0)
  //   POST: y == x
  {
    var x := -3;
    var y := abs1(x);
    // expect y == -3;
    // expect !(x > 0);
  }

  // Test case for combination {1,2}/R5:
  //   POST: !(x > 0)
  //   POST: y == x
  {
    var x := -4;
    var y := abs1(x);
    // expect y == -4;
    // expect !(x > 0);
  }

  // Test case for combination {2}/R2:
  //   POST: y == x
  {
    var x := 2;
    var y := abs1(x);
    // expect y == 2;
  }

  // Test case for combination {2}/R3:
  //   POST: y == x
  {
    var x := 3;
    var y := abs1(x);
    // expect y == 3;
  }

  // Test case for combination {2}/R4:
  //   POST: y == x
  {
    var x := 4;
    var y := abs1(x);
    // expect y == 4;
  }

  // Test case for combination {2}/R5:
  //   POST: y == x
  {
    var x := 5;
    var y := abs1(x);
    // expect y == 5;
  }

}

method Main()
{
  Passing();
  Failing();
}
